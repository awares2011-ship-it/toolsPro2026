import type { Metadata, Viewport } from 'next'
import Script from 'next/script'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import CookieConsent from '@/components/CookieConsent'
import { PUBLISHER_ID } from '@/components/AdBanner'

// ─────────────────────────────────────────────────────────────────────────────
// SITE CONSTANTS — update once, used everywhere
// ─────────────────────────────────────────────────────────────────────────────
export const SITE_URL  = 'https://toolhub.app'
export const SITE_NAME = 'ToolHub'
export const SITE_DESC =
  'Free browser-based tools for developers, writers, and SEO professionals. ' +
  'JSON formatter, password generator, word counter, Base64 encoder, and 30+ more. ' +
  'No signup. No tracking. No cost.'
const OG_IMAGE = `${SITE_URL}/og-default.png`   // 1200×630 PNG — create this image

// ─────────────────────────────────────────────────────────────────────────────
// VIEWPORT — prevents CLS from font scaling on iOS
// ─────────────────────────────────────────────────────────────────────────────
export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#16a34a',
}

// ─────────────────────────────────────────────────────────────────────────────
// ROOT METADATA — shared defaults; individual pages override via generateMetadata
// ─────────────────────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),

  title: {
    default:  `${SITE_NAME} — Free Developer & Productivity Tools`,
    template: `%s | ${SITE_NAME}`,  // e.g. "JSON Formatter | ToolHub"
  },
  description: SITE_DESC,

  keywords: [
    'free online tools', 'developer tools', 'json formatter', 'password generator',
    'word counter', 'base64 encoder', 'uuid generator', 'seo tools', 'text tools',
    'url encoder', 'jwt decoder', 'csv converter', 'sql formatter', 'color picker',
  ],

  authors:   [{ name: 'Breakout Trade', url: `${SITE_URL}/about` }],
  creator:   'Breakout Trade',
  publisher: 'Breakout Trade',

  // ── Open Graph (Facebook, LinkedIn, WhatsApp previews) ──────────────────
  openGraph: {
    siteName:  SITE_NAME,
    type:      'website',
    locale:    'en_GB',
    url:       SITE_URL,
    title:     `${SITE_NAME} — Free Developer & Productivity Tools`,
    description: SITE_DESC,
    images: [{ url: OG_IMAGE, width: 1200, height: 630, alt: 'ToolHub — Free Online Tools' }],
  },

  // ── Twitter / X Card ────────────────────────────────────────────────────
  twitter: {
    card:        'summary_large_image',
    title:       `${SITE_NAME} — Free Developer & Productivity Tools`,
    description: SITE_DESC,
    images:      [OG_IMAGE],
  },

  // ── Crawling ────────────────────────────────────────────────────────────
  robots: {
    index:     true,
    follow:    true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
  alternates: { canonical: SITE_URL },

  // ── Icons ───────────────────────────────────────────────────────────────
  icons: {
    icon:    [{ url: '/favicon.ico' }, { url: '/icon.png', type: 'image/png' }],
    apple:   '/apple-icon.png',
    other:   [{ rel: 'mask-icon', url: '/safari-pinned-tab.svg', color: '#16a34a' }],
  },
  manifest: '/manifest.json',

  // ── Google Search Console verification ──────────────────────────────────
  // Uncomment and add your token from: https://search.google.com/search-console
  // verification: { google: 'YOUR_GSC_VERIFICATION_TOKEN_HERE' },
}

// ─────────────────────────────────────────────────────────────────────────────
// JSON-LD STRUCTURED DATA
// These appear on every page; individual pages add their own schemas on top.
// ─────────────────────────────────────────────────────────────────────────────
const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  '@id': `${SITE_URL}/#organization`,
  name: SITE_NAME,
  alternateName: 'Breakout Trade',
  url: SITE_URL,
  logo: {
    '@type': 'ImageObject',
    url: `${SITE_URL}/icon.png`,
    width: 512,
    height: 512,
  },
  contactPoint: {
    '@type': 'ContactPoint',
    email: 'breakouttradeapp@gmail.com',
    contactType: 'customer support',
    availableLanguage: 'English',
  },
  sameAs: [],
}

const websiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  '@id': `${SITE_URL}/#website`,
  name: SITE_NAME,
  url: SITE_URL,
  description: SITE_DESC,
  publisher: { '@id': `${SITE_URL}/#organization` },
  potentialAction: {
    '@type': 'SearchAction',
    target: { '@type': 'EntryPoint', urlTemplate: `${SITE_URL}/?q={search_term_string}` },
    'query-input': 'required name=search_term_string',
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// ROOT LAYOUT
// ─────────────────────────────────────────────────────────────────────────────
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        {/* ── Preconnect to AdSense CDN for faster ad loading ────────────── */}
        <link rel="preconnect" href="https://pagead2.googlesyndication.com" />
        <link rel="preconnect" href="https://googleads.g.doubleclick.net" />
        <link rel="dns-prefetch" href="https://pagead2.googlesyndication.com" />

        {/* ── Organisation + Website JSON-LD (on every page) ─────────────── */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
        />

        {/* ── AdSense account verification meta tag ───────────────────────
            ADD THIS TAG AS SOON AS YOU HAVE YOUR PUBLISHER ID.
            Google's crawler looks for this to verify site ownership.
            You do NOT need approval yet — add it while applying.
            Replace PUBLISHER_ID with: ca-pub-XXXXXXXXXXXXXXXX
        ─────────────────────────────────────────────────────────────────── */}
        <meta name="google-adsense-account" content={PUBLISHER_ID} />
      </head>

      <body className="flex flex-col min-h-screen bg-white text-gray-900 antialiased">

        {/* ── Google AdSense Script ──────────────────────────────────────────
            strategy="afterInteractive" loads AdSense AFTER the page is
            interactive, protecting LCP + FID Core Web Vitals scores.
            Only uncomment AFTER your AdSense account is approved.
        ──────────────────────────────────────────────────────────────────── */}
        {/* <Script
          id="adsense-script"
          async
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${PUBLISHER_ID}`}
          crossOrigin="anonymous"
          strategy="afterInteractive"
        /> */}

        {/* ── Google Analytics 4 (optional, recommended for AdSense) ─────────
            Replace G-XXXXXXXXXX with your GA4 measurement ID.
            Get one free at: https://analytics.google.com
        ──────────────────────────────────────────────────────────────────── */}
        {/* <Script
          id="ga4-init"
          strategy="afterInteractive"
          src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"
        />
        <Script id="ga4-config" strategy="afterInteractive">{`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'G-XXXXXXXXXX', { anonymize_ip: true });
        `}</Script> */}

        <Header />

        <main id="main-content" className="flex-1">
          {children}
        </main>

        <Footer />
        <CookieConsent />
      </body>
    </html>
  )
}
