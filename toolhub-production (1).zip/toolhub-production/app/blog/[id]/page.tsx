import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { BLOGS } from '@/lib/blogs'
import { TOOLS } from '@/lib/tools'
import BlogCard from '@/components/BlogCard'
import ToolCard from '@/components/ToolCard'
import AdBanner, { AD_SLOTS } from '@/components/AdBanner'
import { SITE_URL, SITE_NAME } from '@/app/layout'

// ─────────────────────────────────────────────────────────────────────────────
// STATIC EXPORT: tell Next.js which blog IDs to pre-render at build time
// ─────────────────────────────────────────────────────────────────────────────
export const dynamic = 'force-static'

export async function generateStaticParams() {
  return BLOGS.map(b => ({ id: b.id }))
}

// ─────────────────────────────────────────────────────────────────────────────
// PER-PAGE METADATA — overrides the root layout defaults
// ─────────────────────────────────────────────────────────────────────────────
interface Props { params: { id: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const blog = BLOGS.find(b => b.id === params.id)
  if (!blog) return {}

  const url       = `${SITE_URL}/blog/${blog.id}`
  const ogImage   = `${SITE_URL}/og-blog-${blog.id}.png`   // generate per-blog OG images for better CTR
  const fallbackOg = `${SITE_URL}/og-default.png`

  return {
    title:       blog.title,
    description: blog.description,
    keywords:    blog.tags,

    alternates: { canonical: url },

    openGraph: {
      title:         blog.title,
      description:   blog.description,
      type:          'article',
      url,
      publishedTime: blog.publishDate,
      modifiedTime:  blog.publishDate,
      authors:       [`${SITE_URL}/about`],
      tags:          blog.tags,
      images: [{
        url:    fallbackOg,  // replace with ogImage once you generate them
        width:  1200,
        height: 630,
        alt:    blog.title,
      }],
    },

    twitter: {
      card:        'summary_large_image',
      title:       blog.title,
      description: blog.description,
      images:      [fallbackOg],
    },
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARKDOWN RENDERER
// Handles: ## H2, ### H3, #### H4, - bullets, ``` code blocks, tables, paragraphs
// Injects a mid-article ad after the 2nd H2 heading automatically.
// ─────────────────────────────────────────────────────────────────────────────
function renderMarkdown(md: string, midAdSlot: string): React.ReactNode[] {
  const lines  = md.split('\n')
  const nodes: React.ReactNode[] = []
  let i        = 0
  let h2count  = 0
  let adDone   = false
  let nodeKey  = 0
  const k = () => nodeKey++

  const inlineParse = (text: string): React.ReactNode[] => {
    // handles **bold**, *italic*, `code`, and [link](url)
    const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\([^)]+\))/g)
    return parts.map((p, idx) => {
      if (p.startsWith('**') && p.endsWith('**'))
        return <strong key={idx} className="font-semibold text-gray-900">{p.slice(2, -2)}</strong>
      if (p.startsWith('*') && p.endsWith('*'))
        return <em key={idx}>{p.slice(1, -1)}</em>
      if (p.startsWith('`') && p.endsWith('`'))
        return <code key={idx} className="bg-gray-100 text-red-600 px-1.5 py-0.5 rounded text-[0.82em] font-mono">{p.slice(1, -1)}</code>
      const linkMatch = p.match(/^\[([^\]]+)\]\(([^)]+)\)$/)
      if (linkMatch)
        return <a key={idx} href={linkMatch[2]} className="text-green-700 underline underline-offset-2 hover:text-green-900">{linkMatch[1]}</a>
      return p
    })
  }

  while (i < lines.length) {
    const line = lines[i]

    // ── Fenced code block ─────────────────────────────────────────────────
    if (line.trimStart().startsWith('```')) {
      const lang   = line.trimStart().slice(3).trim()
      const codeLines: string[] = []
      i++
      while (i < lines.length && !lines[i].trimStart().startsWith('```')) {
        codeLines.push(lines[i]); i++
      }
      nodes.push(
        <div key={k()} className="my-5">
          {lang && (
            <div className="bg-gray-800 text-gray-400 text-[10px] font-mono px-4 py-1.5 rounded-t-xl uppercase tracking-wider">
              {lang}
            </div>
          )}
          <pre className={`bg-gray-900 text-green-300 p-4 overflow-x-auto text-[0.8rem] font-mono whitespace-pre leading-relaxed ${lang ? 'rounded-b-xl' : 'rounded-xl'}`}>
            {codeLines.join('\n')}
          </pre>
        </div>
      )
      i++; continue
    }

    // ── Table ─────────────────────────────────────────────────────────────
    if (line.includes('|') && lines[i + 1]?.includes('---')) {
      const headers = line.split('|').map(h => h.trim()).filter(Boolean)
      i += 2
      const rows: string[][] = []
      while (i < lines.length && lines[i].includes('|')) {
        rows.push(lines[i].split('|').map(c => c.trim()).filter(Boolean)); i++
      }
      nodes.push(
        <div key={k()} className="overflow-x-auto my-6 rounded-xl border border-gray-200">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-gray-50">
              <tr>{headers.map((h, j) => (
                <th key={j} className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider border-b border-gray-200">{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {rows.map((row, j) => (
                <tr key={j} className="odd:bg-white even:bg-gray-50/60 hover:bg-green-50/30 transition-colors">
                  {row.map((cell, ki) => (
                    <td key={ki} className="px-4 py-2.5 text-xs text-gray-600 border-b border-gray-100 last:border-b-0">{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )
      continue
    }

    // ── Headings ──────────────────────────────────────────────────────────
    if (line.startsWith('## ')) {
      h2count++
      nodes.push(
        <h2 key={k()} className="text-xl sm:text-2xl font-bold text-gray-900 mt-10 mb-4 leading-snug">
          {inlineParse(line.slice(3))}
        </h2>
      )
      // ── Inject mid-article ad after 2nd H2 ──────────────────────────────
      if (h2count === 2 && !adDone) {
        adDone = true
        nodes.push(
          <div key="mid-ad" className="my-8 rounded-2xl overflow-hidden bg-gray-50 p-3">
            <AdBanner slot={midAdSlot} format="rectangle" />
          </div>
        )
      }
      i++; continue
    }
    if (line.startsWith('### ')) {
      nodes.push(
        <h3 key={k()} className="text-base sm:text-lg font-semibold text-gray-900 mt-7 mb-2">
          {inlineParse(line.slice(4))}
        </h3>
      )
      i++; continue
    }
    if (line.startsWith('#### ')) {
      nodes.push(
        <h4 key={k()} className="text-sm font-semibold text-gray-800 mt-5 mb-1.5">
          {inlineParse(line.slice(5))}
        </h4>
      )
      i++; continue
    }

    // ── Numbered list ─────────────────────────────────────────────────────
    if (/^\d+\. /.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\d+\. /.test(lines[i])) {
        items.push(lines[i].replace(/^\d+\. /, '')); i++
      }
      nodes.push(
        <ol key={k()} className="list-decimal list-inside space-y-2 my-4 text-gray-600 text-sm leading-relaxed">
          {items.map((it, j) => <li key={j} className="pl-1">{inlineParse(it)}</li>)}
        </ol>
      )
      continue
    }

    // ── Bullet list ───────────────────────────────────────────────────────
    if (line.startsWith('- ') || line.startsWith('• ')) {
      const items: string[] = []
      while (i < lines.length && (lines[i].startsWith('- ') || lines[i].startsWith('• '))) {
        items.push(lines[i].slice(2)); i++
      }
      nodes.push(
        <ul key={k()} className="space-y-2 my-4 text-gray-600 text-sm leading-relaxed">
          {items.map((it, j) => (
            <li key={j} className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5 shrink-0">▸</span>
              <span>{inlineParse(it)}</span>
            </li>
          ))}
        </ul>
      )
      continue
    }

    // ── Blockquote ────────────────────────────────────────────────────────
    if (line.startsWith('> ')) {
      nodes.push(
        <blockquote key={k()} className="border-l-4 border-green-400 bg-green-50 pl-4 pr-3 py-3 my-5 rounded-r-lg">
          <p className="text-sm text-gray-700 italic leading-relaxed">{inlineParse(line.slice(2))}</p>
        </blockquote>
      )
      i++; continue
    }

    // ── Horizontal rule ───────────────────────────────────────────────────
    if (line.trim() === '---') {
      nodes.push(<hr key={k()} className="border-gray-200 my-8" />)
      i++; continue
    }

    // ── Blank line ────────────────────────────────────────────────────────
    if (!line.trim()) { i++; continue }

    // ── Paragraph ────────────────────────────────────────────────────────
    nodes.push(
      <p key={k()} className="text-gray-600 text-sm sm:text-[15px] leading-[1.85] mb-4">
        {inlineParse(line)}
      </p>
    )
    i++
  }
  return nodes
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function BlogPost({ params }: Props) {
  const blog = BLOGS.find(b => b.id === params.id)
  if (!blog) notFound()

  const relatedBlogs = blog.relatedBlogs
    .map(id => BLOGS.find(b => b.id === id))
    .filter(Boolean) as typeof BLOGS

  const relatedTool = TOOLS.find(t => t.id === blog.relatedTool)

  const pageUrl = `${SITE_URL}/blog/${blog.id}`

  // ── BlogPosting JSON-LD (replaces generic "Article") ────────────────────
  // Google uses BlogPosting for richer search results + indexing signals.
  const blogPostingSchema = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    '@id': pageUrl,
    headline:      blog.title,
    description:   blog.description,
    url:           pageUrl,
    datePublished: blog.publishDate,
    dateModified:  blog.publishDate,
    inLanguage:    'en-GB',
    wordCount:     blog.content.split(/\s+/).length,
    timeRequired:  `PT${blog.readTime}M`,
    keywords:      blog.tags.join(', '),
    articleSection: blog.category,
    author: {
      '@type': 'Organization',
      '@id':   `${SITE_URL}/#organization`,
      name:    'Breakout Trade',
      url:     `${SITE_URL}/about`,
    },
    publisher: {
      '@type': 'Organization',
      '@id':   `${SITE_URL}/#organization`,
      name:    SITE_NAME,
      logo: {
        '@type': 'ImageObject',
        url:     `${SITE_URL}/icon.png`,
        width:   512,
        height:  512,
      },
    },
    mainEntityOfPage: { '@type': 'WebPage', '@id': pageUrl },
    image: {
      '@type':  'ImageObject',
      url:      `${SITE_URL}/og-default.png`,
      width:    1200,
      height:   630,
    },
    isPartOf: { '@id': `${SITE_URL}/#website` },
  }

  // ── BreadcrumbList JSON-LD ───────────────────────────────────────────────
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home',  item: SITE_URL },
      { '@type': 'ListItem', position: 2, name: 'Blog',  item: `${SITE_URL}/blog` },
      { '@type': 'ListItem', position: 3, name: blog.title, item: pageUrl },
    ],
  }

  return (
    <>
      {/* ── Structured data ─────────────────────────────────────────────── */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(blogPostingSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">

        {/* ── Breadcrumb ───────────────────────────────────────────────── */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-gray-400 mb-6 flex-wrap">
          <Link href="/" className="hover:text-green-700 transition-colors">Home</Link>
          <span aria-hidden>/</span>
          <Link href="/blog" className="hover:text-green-700 transition-colors">Blog</Link>
          <span aria-hidden>/</span>
          <span className="text-gray-600 truncate max-w-[220px]" aria-current="page">{blog.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">

          {/* ── Article ─────────────────────────────────────────────────── */}
          <article className="lg:col-span-2" itemScope itemType="https://schema.org/BlogPosting">

            {/* Category + meta row */}
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <Link
                href={`/blog?category=${blog.category.toLowerCase()}`}
                className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-green-100 text-green-700 hover:bg-green-200 transition-colors"
              >
                {blog.category}
              </Link>
              <span className="text-xs text-gray-400">
                <span itemProp="timeRequired" content={`PT${blog.readTime}M`}>{blog.readTime} min read</span>
              </span>
              <span className="text-gray-200">·</span>
              <time
                className="text-xs text-gray-400"
                dateTime={blog.publishDate}
                itemProp="datePublished"
              >
                {new Date(blog.publishDate).toLocaleDateString('en-GB', {
                  day: 'numeric', month: 'long', year: 'numeric',
                })}
              </time>
              <span className="text-gray-200">·</span>
              <span className="text-xs text-gray-400">
                By <strong className="text-gray-600" itemProp="author">Breakout Trade</strong>
              </span>
            </div>

            {/* Title */}
            <h1
              className="text-2xl sm:text-3xl font-bold text-gray-900 leading-snug mb-4"
              itemProp="headline"
            >
              {blog.title}
            </h1>

            {/* Description / lead */}
            <p className="text-gray-500 text-sm sm:text-base leading-relaxed mb-8 pb-6 border-b border-gray-100" itemProp="description">
              {blog.description}
            </p>

            {/* Body — mid ad injected after 2nd H2 */}
            <div itemProp="articleBody">
              {renderMarkdown(blog.content, AD_SLOTS.BLOG_MID)}
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mt-10 pt-6 border-t border-gray-100">
              {blog.tags.map(tag => (
                <span
                  key={tag}
                  className="text-[10px] font-semibold bg-gray-100 text-gray-500 px-2.5 py-1 rounded-full hover:bg-gray-200 transition-colors cursor-default"
                >
                  #{tag}
                </span>
              ))}
            </div>

            {/* Author card */}
            <div className="mt-8 p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center gap-4">
              <div className="w-11 h-11 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold text-base shrink-0">
                BT
              </div>
              <div>
                <p className="text-sm font-bold text-gray-800">Breakout Trade</p>
                <p className="text-xs text-gray-500 mt-0.5">
                  ToolHub content team — writing practical guides for developers, writers, and SEO professionals.
                </p>
              </div>
            </div>

            {/* Share nudge */}
            <div className="mt-6 p-3 bg-blue-50 rounded-xl border border-blue-100 flex items-center justify-between gap-3 flex-wrap">
              <p className="text-xs text-blue-700 font-medium">Found this helpful? Share it!</p>
              <div className="flex gap-2">
                <a
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(blog.title)}&url=${encodeURIComponent(pageUrl)}`}
                  target="_blank" rel="noopener noreferrer"
                  className="text-[11px] font-semibold px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                >
                  Share on X
                </a>
              </div>
            </div>
          </article>

          {/* ── Sidebar ─────────────────────────────────────────────────── */}
          <aside className="space-y-6">

            {/* Related tool CTA — high-value internal link */}
            {relatedTool && (
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-100 rounded-2xl p-5">
                <p className="text-[10px] font-bold text-green-600 uppercase tracking-wider mb-2">
                  🛠 Try the free tool
                </p>
                <p className="text-sm font-bold text-green-900 mb-1">{relatedTool.name}</p>
                <p className="text-xs text-green-700 mb-4 leading-relaxed">{relatedTool.shortDesc}</p>
                <Link
                  href={`/tools/${relatedTool.id}`}
                  className="block text-center text-xs font-bold bg-green-600 hover:bg-green-700 text-white rounded-xl py-2.5 transition-colors"
                >
                  Open {relatedTool.name} →
                </Link>
              </div>
            )}

            {/* Sidebar rectangle ad */}
            <AdBanner slot={AD_SLOTS.BLOG_SIDEBAR} format="rectangle" />

            {/* Related articles */}
            {relatedBlogs.length > 0 && (
              <div>
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
                  Related Articles
                </p>
                <div className="space-y-3">
                  {relatedBlogs.map(b => <BlogCard key={b.id} blog={b} />)}
                </div>
              </div>
            )}

            {/* Browse all */}
            <Link
              href="/blog"
              className="flex items-center justify-center gap-1 text-xs font-semibold text-green-700 border border-green-200 rounded-xl py-3 hover:bg-green-50 transition-colors"
            >
              ← All articles
            </Link>
          </aside>
        </div>

        {/* ── Footer leaderboard ad ────────────────────────────────────── */}
        <div className="mt-12 pt-8 border-t border-gray-100">
          <AdBanner slot={AD_SLOTS.FOOTER_BANNER} format="leaderboard" />
        </div>
      </div>
    </>
  )
}
