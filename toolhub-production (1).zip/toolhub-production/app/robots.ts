// app/robots.ts
// ─────────────────────────────────────────────────────────────────────────────
// Generates /robots.txt at build time (Next.js 14 App Router).
//
// Key rules:
//  - Allow all legitimate search engine crawlers
//  - Block Next.js internals (_next/) from being indexed
//  - Optionally block AI training bots (your choice — see note below)
//  - Always include the sitemap URL
// ─────────────────────────────────────────────────────────────────────────────
import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      // ── Allow all well-behaved bots ──────────────────────────────────
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/_next/',     // Next.js build assets — not useful to index
          '/api/',       // no public API routes
          '/static/',    // raw static assets
          '/404',        // error page
        ],
      },

      // ── Block AI training scrapers (optional) ────────────────────────
      // These bots harvest content for training LLMs.
      // Blocking them does NOT affect Google, Bing, or ad bots.
      // If you WANT AI traffic for brand awareness, comment these out.
      { userAgent: 'GPTBot',           disallow: '/' },
      { userAgent: 'ChatGPT-User',     disallow: '/' },
      { userAgent: 'Google-Extended',  disallow: '/' },
      { userAgent: 'anthropic-ai',     disallow: '/' },
      { userAgent: 'ClaudeBot',        disallow: '/' },
      { userAgent: 'cohere-ai',        disallow: '/' },
      { userAgent: 'PerplexityBot',    disallow: '/' },
      { userAgent: 'Amazonbot',        disallow: '/' },

      // ── Explicitly allow Google AdSense crawler ──────────────────────
      // Mediapartners-Google scans your pages to serve contextual ads.
      // It must be allowed for AdSense to work correctly.
      { userAgent: 'Mediapartners-Google', allow: '/' },
    ],

    sitemap: 'https://toolhub.app/sitemap.xml',
    host:    'https://toolhub.app',
  }
}
