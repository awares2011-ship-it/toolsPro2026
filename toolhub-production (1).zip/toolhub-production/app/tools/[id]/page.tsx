import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { TOOLS, CATEGORIES, getToolById, getRelatedTools } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'
import ToolRenderer from '@/components/ToolRenderer'
import ToolCard from '@/components/ToolCard'
import BlogCard from '@/components/BlogCard'
import AdBanner, { AD_SLOTS } from '@/components/AdBanner'
import { SITE_URL, SITE_NAME } from '@/app/layout'

// ─────────────────────────────────────────────────────────────────────────────
// STATIC EXPORT
// ─────────────────────────────────────────────────────────────────────────────
export const dynamic = 'force-static'

export async function generateStaticParams() {
  return TOOLS.map(t => ({ id: t.id }))
}

// ─────────────────────────────────────────────────────────────────────────────
// PER-PAGE METADATA
// ─────────────────────────────────────────────────────────────────────────────
interface Props { params: { id: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const tool = getToolById(params.id)
  if (!tool) return {}

  const url   = `${SITE_URL}/tools/${tool.id}`
  const title = `${tool.name} — Free Online Tool`
  const desc  = `${tool.longDesc} Free to use, no signup required. Works entirely in your browser.`

  return {
    title,
    description: desc,
    keywords: tool.keywords,
    alternates: { canonical: url },
    openGraph: {
      title,
      description: desc,
      type:        'website',
      url,
      images: [{ url: `${SITE_URL}/og-default.png`, width: 1200, height: 630 }],
    },
    twitter: { card: 'summary_large_image', title, description: desc },
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function ToolPage({ params }: Props) {
  const tool = getToolById(params.id)
  if (!tool) notFound()

  const cat         = CATEGORIES.find(c => c.id === tool.category)
  const related     = getRelatedTools(tool, 4)
  const pageUrl     = `${SITE_URL}/tools/${tool.id}`

  // Find blog posts that reference this tool (for internal linking)
  const relatedBlogs = BLOGS.filter(b => b.relatedTool === tool.id).slice(0, 3)

  // ── SoftwareApplication JSON-LD ─────────────────────────────────────────
  // This is the schema Google recommends for web-based tools / apps.
  // Eligible for rich results (rating stars, price badge) in SERPs.
  const softwareAppSchema = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    '@id': pageUrl,
    name:            tool.name,
    description:     tool.longDesc,
    url:             pageUrl,
    applicationCategory: 'WebApplication',
    operatingSystem: 'Any',     // browser-based → runs on all OS
    browserRequirements: 'Requires a modern browser with JavaScript enabled.',
    inLanguage:      'en',
    isAccessibleForFree: true,
    offers: {
      '@type': 'Offer',
      price:    '0',
      priceCurrency: 'USD',
    },
    // Aggregate rating — once you have real user data, populate this.
    // aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.8', ratingCount: '120' },
    author: {
      '@type': 'Organization',
      '@id':   `${SITE_URL}/#organization`,
      name:    SITE_NAME,
      url:     SITE_URL,
    },
    publisher: { '@id': `${SITE_URL}/#organization` },
    mainEntityOfPage: { '@type': 'WebPage', '@id': pageUrl },
  }

  // ── BreadcrumbList JSON-LD ───────────────────────────────────────────────
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home',    item: SITE_URL },
      { '@type': 'ListItem', position: 2, name: cat?.name ?? 'Tools', item: `${SITE_URL}/tools/category/${tool.category}` },
      { '@type': 'ListItem', position: 3, name: tool.name, item: pageUrl },
    ],
  }

  // ── FAQPage JSON-LD — boosts organic CTR via FAQ rich snippet ───────────
  // Customise these per tool. Even 2–3 FAQs can win a rich result.
  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: `Is ${tool.name} free to use?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Yes — ${tool.name} on ToolHub is completely free. No signup or account is required.`,
        },
      },
      {
        '@type': 'Question',
        name: `Is my data safe when using ${tool.name}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Absolutely. ${tool.name} runs entirely in your browser. No data is sent to any server, so your information never leaves your device.`,
        },
      },
      {
        '@type': 'Question',
        name: `Can I use ${tool.name} on mobile?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Yes. ${tool.name} is fully responsive and works on all devices including smartphones and tablets.`,
        },
      },
    ],
  }

  return (
    <>
      {/* ── Structured data ───────────────────────────────────────────── */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareAppSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">

        {/* ── Breadcrumb ───────────────────────────────────────────────── */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-gray-400 mb-6 flex-wrap">
          <Link href="/" className="hover:text-green-700 transition-colors">Home</Link>
          <span aria-hidden>/</span>
          <Link href={`/tools/category/${tool.category}`} className="hover:text-green-700 transition-colors">
            {cat?.icon} {cat?.name}
          </Link>
          <span aria-hidden>/</span>
          <span className="text-gray-600" aria-current="page">{tool.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* ── Tool panel ──────────────────────────────────────────────── */}
          <div className="lg:col-span-2">

            {/* Title + description */}
            <div className="mb-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">{tool.icon}</span>
                <h1 className="text-2xl font-bold text-gray-900">{tool.name}</h1>
              </div>
              <p className="text-sm text-gray-500 leading-relaxed">{tool.longDesc}</p>
            </div>

            {/* Guarantee badges — builds trust (important for AdSense approval) */}
            <div className="flex flex-wrap gap-2 mb-5">
              {['🔒 Private — runs in browser', '⚡ Instant results', '📱 Mobile friendly', '✅ Free forever'].map(badge => (
                <span key={badge} className="text-[11px] font-medium bg-green-50 text-green-700 border border-green-100 px-2.5 py-1 rounded-full">
                  {badge}
                </span>
              ))}
            </div>

            {/* Tool UI */}
            <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
              <ToolRenderer toolId={tool.id} />
            </div>

            {/* Ad below tool — horizontal leaderboard */}
            <div className="mt-6">
              <AdBanner slot={AD_SLOTS.TOOL_BELOW} format="horizontal" />
            </div>

            {/* How to use section — adds page content depth for SEO */}
            <section className="mt-8 bg-gray-50 rounded-2xl border border-gray-100 p-6" aria-labelledby="how-to-use">
              <h2 id="how-to-use" className="text-base font-bold text-gray-900 mb-4">
                How to Use {tool.name}
              </h2>
              <ol className="space-y-3">
                {[
                  'Paste or type your input into the text area above.',
                  'The result appears instantly — no button press needed.',
                  'Click "Copy" to copy the output to your clipboard.',
                  'Use the output directly in your project or workflow.',
                ].map((step, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-gray-600">
                    <span className="w-5 h-5 rounded-full bg-green-100 text-green-700 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    {step}
                  </li>
                ))}
              </ol>
            </section>

            {/* FAQ section — triggers FAQ rich snippets in Google */}
            <section className="mt-8" aria-labelledby="faq">
              <h2 id="faq" className="text-base font-bold text-gray-900 mb-4">
                Frequently Asked Questions
              </h2>
              <div className="space-y-4">
                {[
                  {
                    q: `Is ${tool.name} free to use?`,
                    a: `Yes — completely free. No account, no credit card, no usage limits.`,
                  },
                  {
                    q: `Is my data private?`,
                    a: `Your data never leaves your browser. ${tool.name} processes everything locally — nothing is sent to our servers.`,
                  },
                  {
                    q: `Does it work on mobile?`,
                    a: `Yes. ${tool.name} is fully responsive and works on smartphones, tablets, and desktop computers.`,
                  },
                ].map(({ q, a }, i) => (
                  <details key={i} className="group border border-gray-200 rounded-xl overflow-hidden">
                    <summary className="px-4 py-3 text-sm font-semibold text-gray-800 cursor-pointer hover:bg-gray-50 transition-colors list-none flex items-center justify-between">
                      {q}
                      <span className="text-gray-400 group-open:rotate-180 transition-transform">▾</span>
                    </summary>
                    <p className="px-4 pb-4 pt-2 text-sm text-gray-600 leading-relaxed">{a}</p>
                  </details>
                ))}
              </div>
            </section>

            {/* Related blog posts — internal linking for SEO */}
            {relatedBlogs.length > 0 && (
              <section className="mt-8" aria-labelledby="related-guides">
                <h2 id="related-guides" className="text-base font-bold text-gray-900 mb-4">
                  Related Guides & Articles
                </h2>
                <div className="grid gap-3">
                  {relatedBlogs.map(b => <BlogCard key={b.id} blog={b} />)}
                </div>
              </section>
            )}
          </div>

          {/* ── Sidebar ─────────────────────────────────────────────────── */}
          <aside className="space-y-6">

            {/* About this tool */}
            <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4">About this tool</p>
              <ul className="space-y-3">
                {[
                  { icon: '🌐', text: 'Runs entirely in your browser' },
                  { icon: '🔒', text: 'No data sent to any server' },
                  { icon: '🆓', text: 'Free — no signup required' },
                  { icon: '📱', text: 'Works on mobile and desktop' },
                  { icon: '⚡', text: 'Instant — no loading wait' },
                ].map(({ icon, text }) => (
                  <li key={text} className="flex items-start gap-2.5 text-xs text-gray-600">
                    <span className="text-base leading-none mt-0.5">{icon}</span>
                    {text}
                  </li>
                ))}
              </ul>
            </div>

            {/* Sidebar rectangle ad */}
            <AdBanner slot={AD_SLOTS.BLOG_SIDEBAR} format="rectangle" />

            {/* Related tools */}
            {related.length > 0 && (
              <div>
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
                  Related Tools
                </p>
                <div className="space-y-2">
                  {related.map(t => <ToolCard key={t.id} tool={t} />)}
                </div>
              </div>
            )}

            {/* Category link */}
            <Link
              href={`/tools/category/${tool.category}`}
              className="flex items-center justify-center gap-1 text-xs font-semibold text-green-700 border border-green-200 rounded-xl py-3 hover:bg-green-50 transition-colors"
            >
              View all {cat?.name} →
            </Link>

            {/* All tools link */}
            <Link
              href="/"
              className="flex items-center justify-center gap-1 text-xs font-semibold text-gray-600 border border-gray-200 rounded-xl py-3 hover:bg-gray-50 transition-colors"
            >
              ← All Tools
            </Link>
          </aside>
        </div>

        {/* ── Footer leaderboard ad ────────────────────────────────────── */}
        <div className="mt-12 pt-8 border-t border-gray-100">
          <AdBanner slot={AD_SLOTS.FOOTER_BANNER} format="leaderboard" />
        </div>
      </div>
    </>
  )
}
