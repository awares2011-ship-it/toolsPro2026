// app/sitemap.ts
// ─────────────────────────────────────────────────────────────────────────────
// Dynamic sitemap — Next.js generates /sitemap.xml at build time.
// Static export compatible: no server-only APIs used.
// Submit to Google Search Console: https://search.google.com/search-console
// ─────────────────────────────────────────────────────────────────────────────
import type { MetadataRoute } from 'next'
import { TOOLS, CATEGORIES } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'

const BASE = 'https://toolhub.app'

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date().toISOString()

  // ── Tier 1: Static core pages ─────────────────────────────────────────
  const staticPages: MetadataRoute.Sitemap = [
    {
      url:             BASE,
      lastModified:    now,
      changeFrequency: 'daily',
      priority:        1.0,
    },
    {
      url:             `${BASE}/blog`,
      lastModified:    now,
      changeFrequency: 'daily',     // new posts → daily
      priority:        0.9,
    },
    {
      url:             `${BASE}/about`,
      lastModified:    now,
      changeFrequency: 'monthly',
      priority:        0.7,
    },
    {
      url:             `${BASE}/contact`,
      lastModified:    now,
      changeFrequency: 'monthly',
      priority:        0.6,
    },
    {
      url:             `${BASE}/privacy`,
      lastModified:    now,
      changeFrequency: 'yearly',
      priority:        0.4,
    },
    {
      url:             `${BASE}/terms`,
      lastModified:    now,
      changeFrequency: 'yearly',
      priority:        0.4,
    },
  ]

  // ── Tier 2: Tool pages — highest value pages ──────────────────────────
  // priority 0.85: just below homepage/blog hub, above categories.
  const toolPages: MetadataRoute.Sitemap = TOOLS.map(t => ({
    url:             `${BASE}/tools/${t.id}`,
    lastModified:    now,
    changeFrequency: 'monthly' as const,
    priority:        0.85,
  }))

  // ── Tier 3: Category hub pages ─────────────────────────────────────────
  const categoryPages: MetadataRoute.Sitemap = CATEGORIES.map(c => ({
    url:             `${BASE}/tools/category/${c.id}`,
    lastModified:    now,
    changeFrequency: 'weekly' as const,
    priority:        0.75,
  }))

  // ── Tier 4: Blog / guide pages ─────────────────────────────────────────
  // Use the actual publish date so Google can track freshness.
  const blogPages: MetadataRoute.Sitemap = BLOGS.map(b => ({
    url:             `${BASE}/blog/${b.id}`,
    lastModified:    new Date(b.publishDate).toISOString(),
    changeFrequency: 'monthly' as const,
    priority:        0.70,
  }))

  return [
    ...staticPages,
    ...toolPages,
    ...categoryPages,
    ...blogPages,
  ]
}
