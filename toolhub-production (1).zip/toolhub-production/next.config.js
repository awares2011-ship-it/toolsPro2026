/** @type {import('next').NextConfig} */
const nextConfig = {
  // ── Static export — required for Firebase Hosting ──────────────────────
  // This tells Next.js to generate a static /out directory (no Node server).
  // Firebase Hosting serves these files directly from its global CDN.
  output: 'export',

  // ── Trailing slash — makes Firebase routes work without rewrites ────────
  // /about/ is served as /about/index.html instead of /about.html.
  // Required for Firebase Hosting to resolve dynamic routes correctly.
  trailingSlash: true,

  // ── Image optimisation ──────────────────────────────────────────────────
  // next/image's built-in optimiser requires a Node.js server.
  // With output: 'export' we disable it and use a third-party loader instead.
  // If you don't use next/image at all, you can remove this block.
  images: {
    unoptimized: true,
  },

  // ── Compiler options ────────────────────────────────────────────────────
  // Remove console.log calls in production builds (cleaner, faster)
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production' ? { exclude: ['error', 'warn'] } : false,
  },

  // ── Experimental: faster builds ─────────────────────────────────────────
  experimental: {
    // Parallel route-building — speeds up `next build` significantly
    workerThreads: true,
    cpus:          4,
  },
}

module.exports = nextConfig
