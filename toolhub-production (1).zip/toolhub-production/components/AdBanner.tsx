'use client'
import { useEffect, useRef, useState } from 'react'

// ─────────────────────────────────────────────────────────────────────────────
// STEP 1: Replace with your real AdSense Publisher ID
//         Format: ca-pub-XXXXXXXXXXXXXXXX  (16 digits)
//         Found at: https://adsense.google.com → Account → Account info
// ─────────────────────────────────────────────────────────────────────────────
export const PUBLISHER_ID = 'ca-pub-XXXXXXXXXXXXXXXX'

// ─────────────────────────────────────────────────────────────────────────────
// STEP 2: Replace each slot ID after your AdSense account is approved.
//         Create ad units at: AdSense → Ads → By ad unit → Display ads
//         Recommended sizes listed per slot.
// ─────────────────────────────────────────────────────────────────────────────
export const AD_SLOTS = {
  /** Homepage — below hero section. Responsive leaderboard (728×90 desktop / 320×50 mobile) */
  HOME_LEADERBOARD:  '1111111111',
  /** Tool pages — directly below tool output panel. Responsive horizontal. */
  TOOL_BELOW:        '2222222222',
  /** Blog posts — injected after the 2nd H2 heading. Responsive rectangle (300×250). */
  BLOG_MID:          '3333333333',
  /** Right sidebar on blog + tool pages. Fixed 300×250. */
  BLOG_SIDEBAR:      '4444444444',
  /** Above footer on all pages. Full-width leaderboard (970×90 / responsive). */
  FOOTER_BANNER:     '5555555555',
  /** Blog list page — between blog card rows. */
  BLOG_LIST_MID:     '6666666666',
} as const

export type AdSlotKey = keyof typeof AD_SLOTS

// ─────────────────────────────────────────────────────────────────────────────
// CLS-safe minimum heights — reserve space before the ad loads so the page
// does not jump (Core Web Vitals: CLS must stay under 0.1).
// ─────────────────────────────────────────────────────────────────────────────
const FORMAT_MIN_HEIGHT: Record<string, number> = {
  horizontal:  90,
  leaderboard: 90,
  rectangle:   250,
  vertical:    600,
  auto:        90,
}

interface AdBannerProps {
  /** Ad slot ID from AD_SLOTS above */
  slot: string
  /** AdSense format value — controls the ad unit shape */
  format?: 'auto' | 'horizontal' | 'rectangle' | 'vertical' | 'leaderboard'
  /** Extra Tailwind classes applied to the outer wrapper div */
  className?: string
  /** Show the "Advertisement" disclosure label (required by some ad policies). Default: true */
  showLabel?: boolean
  /** Lazy-load the ad (uses IntersectionObserver). Default: true. Set false for above-fold ads. */
  lazy?: boolean
}

declare global {
  interface Window { adsbygoogle: unknown[] }
}

export default function AdBanner({
  slot,
  format = 'auto',
  className = '',
  showLabel = true,
  lazy = true,
}: AdBannerProps) {
  const wrapperRef  = useRef<HTMLDivElement>(null)
  const pushed      = useRef(false)
  const [visible, setVisible] = useState(!lazy)

  // ── Intersection Observer for lazy ads ──────────────────────────────────
  useEffect(() => {
    if (!lazy || visible) return
    const el = wrapperRef.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect() } },
      { rootMargin: '300px' }   // start loading 300px before the ad enters the viewport
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [lazy, visible])

  // ── Push the ad unit once visible ───────────────────────────────────────
  useEffect(() => {
    if (!visible || pushed.current) return
    pushed.current = true
    try {
      const adsByGoogle = (window.adsbygoogle = window.adsbygoogle || [])
      adsByGoogle.push({})
    } catch {
      // AdSense not loaded yet (e.g. blocked by ad blocker) — fail silently
    }
  }, [visible])

  const minH = FORMAT_MIN_HEIGHT[format] ?? 90

  return (
    // Outer wrapper reserves height before the ad loads to prevent layout shift (CLS).
    <div
      ref={wrapperRef}
      className={`w-full overflow-hidden ${className}`}
      style={{ minHeight: minH }}
      aria-label="Advertisement"
    >
      {showLabel && (
        <p className="text-[9px] text-gray-400 uppercase tracking-widest text-center mb-1 select-none font-medium">
          Advertisement
        </p>
      )}

      {visible && (
        <ins
          className="adsbygoogle"
          style={{ display: 'block', minHeight: minH }}
          data-ad-client={PUBLISHER_ID}
          data-ad-slot={slot}
          data-ad-format={format}
          data-full-width-responsive="true"
        />
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Pre-configured convenience wrappers (import and drop in anywhere)
// ─────────────────────────────────────────────────────────────────────────────

/** Above-the-fold homepage leaderboard — NOT lazy (loads immediately) */
export function HomeLeaderboardAd({ className = '' }: { className?: string }) {
  return (
    <AdBanner
      slot={AD_SLOTS.HOME_LEADERBOARD}
      format="leaderboard"
      lazy={false}
      className={className}
    />
  )
}

/** Below-tool horizontal ad */
export function ToolBelowAd({ className = '' }: { className?: string }) {
  return (
    <AdBanner
      slot={AD_SLOTS.TOOL_BELOW}
      format="horizontal"
      className={className}
    />
  )
}

/** Mid-blog rectangle ad */
export function BlogMidAd({ className = '' }: { className?: string }) {
  return (
    <AdBanner
      slot={AD_SLOTS.BLOG_MID}
      format="rectangle"
      className={className}
    />
  )
}

/** Sidebar 300×250 rectangle ad */
export function SidebarAd({ className = '' }: { className?: string }) {
  return (
    <AdBanner
      slot={AD_SLOTS.BLOG_SIDEBAR}
      format="rectangle"
      className={className}
    />
  )
}

/** Above-footer full-width leaderboard */
export function FooterLeaderboardAd({ className = '' }: { className?: string }) {
  return (
    <AdBanner
      slot={AD_SLOTS.FOOTER_BANNER}
      format="leaderboard"
      className={`mt-8 pt-6 border-t border-gray-100 ${className}`}
    />
  )
}
