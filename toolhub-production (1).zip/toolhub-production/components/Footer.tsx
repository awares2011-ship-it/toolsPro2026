import Link from 'next/link'
import { CATEGORIES } from '@/lib/tools'
import { FooterLeaderboardAd } from '@/components/AdBanner'

const OWNER   = 'Breakout Trade'
const EMAIL   = 'breakouttradeapp@gmail.com'
const SITE    = 'ToolHub'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="border-t border-gray-100 bg-gray-50 mt-12">

      {/* ── Footer leaderboard ad — appears on EVERY page ──────────────── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        <FooterLeaderboardAd />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-8">

          {/* Brand */}
          <div className="col-span-2 sm:col-span-1">
            <Link href="/" className="flex items-center gap-1.5 mb-3">
              <span
                className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black text-white"
                style={{ background: 'linear-gradient(135deg,#16a34a,#059669)' }}
              >
                ⚡
              </span>
              <span className="font-bold text-gray-900 text-sm">
                Tool<span className="text-green-600">Hub</span>
              </span>
            </Link>
            <p className="text-xs text-gray-500 leading-relaxed mb-2">
              Free browser-based tools for developers, writers, and SEO professionals.
              No signup, no tracking, no cost.
            </p>
            <p className="text-xs text-gray-400">
              Owned by <strong className="text-gray-500">{OWNER}</strong>
            </p>
            <a
              href={`mailto:${EMAIL}`}
              className="mt-2 block text-xs text-green-600 hover:underline"
            >
              {EMAIL}
            </a>
          </div>

          {/* Tools */}
          <div>
            <p className="text-xs font-semibold text-gray-700 uppercase tracking-wider mb-3">Tools</p>
            <ul className="space-y-2">
              {CATEGORIES.map(cat => (
                <li key={cat.id}>
                  <Link
                    href={`/tools/category/${cat.id}`}
                    className="text-xs text-gray-500 hover:text-green-700 transition-colors"
                  >
                    {cat.icon} {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <p className="text-xs font-semibold text-gray-700 uppercase tracking-wider mb-3">Resources</p>
            <ul className="space-y-2">
              <li><Link href="/blog"    className="text-xs text-gray-500 hover:text-green-700 transition-colors">Blog &amp; Guides</Link></li>
              <li><Link href="/about"   className="text-xs text-gray-500 hover:text-green-700 transition-colors">About {SITE}</Link></li>
              <li><Link href="/contact" className="text-xs text-gray-500 hover:text-green-700 transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <p className="text-xs font-semibold text-gray-700 uppercase tracking-wider mb-3">Legal</p>
            <ul className="space-y-2">
              <li><Link href="/privacy" className="text-xs text-gray-500 hover:text-green-700 transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms"   className="text-xs text-gray-500 hover:text-green-700 transition-colors">Terms of Service</Link></li>
            </ul>

            {/* Trust badges */}
            <div className="mt-5 space-y-1.5">
              <p className="text-[10px] text-gray-400 flex items-center gap-1">
                <span className="text-green-500">✓</span> No data sent to servers
              </p>
              <p className="text-[10px] text-gray-400 flex items-center gap-1">
                <span className="text-green-500">✓</span> No cookies set by tools
              </p>
              <p className="text-[10px] text-gray-400 flex items-center gap-1">
                <span className="text-green-500">✓</span> HTTPS secured
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-gray-400">
            © {year} {SITE} by <strong>{OWNER}</strong>. All rights reserved.
          </p>
          <p className="text-xs text-gray-400">
            All tools run in your browser — your data never leaves your device.
          </p>
        </div>
      </div>
    </footer>
  )
}
