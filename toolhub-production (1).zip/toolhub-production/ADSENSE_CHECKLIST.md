# ✅ AdSense Pre-Approval Checklist for ToolHub
## Complete this list before applying — saves you from rejection

---

## 🔴 CRITICAL (Rejection guaranteed if missing)

- [ ] **Privacy Policy** at `/privacy` mentions:
  - Google AdSense and third-party cookies
  - Data collected by ads (IP, browsing behaviour)
  - How users can opt out (Google's ad settings link)

- [ ] **Terms of Service** at `/terms` — complete, not placeholder text

- [ ] **About page** at `/about` — explains who owns the site and its purpose

- [ ] **Contact page** at `/contact` — includes a **real, working email address**
  (Gmail is fine — `breakouttradeapp@gmail.com` already present ✓)

- [ ] **No empty or stub pages** — every page in the sitemap must have real content

- [ ] **No duplicate content** — every blog post must be original text

- [ ] **HTTPS** — Firebase Hosting enables this automatically ✓

---

## 🟡 IMPORTANT (Rejection likely if missing)

- [ ] At least **20 blog posts**, each:
  - 800+ words of original content
  - Proper heading structure (H1 → H2 → H3)
  - Internal links to tools and related articles
  - Real author name and publish date

- [ ] At least **15 tool pages** — fully functional, no broken UIs

- [ ] **No broken links** — check with: `npx broken-link-checker https://toolhub.app -ro`

- [ ] **Mobile responsive** — test at: https://web.dev/measure/

- [ ] **Core Web Vitals pass** on Google's Lighthouse:
  - LCP < 2.5 seconds
  - CLS < 0.1
  - FID / INP < 200ms

- [ ] **`<meta name="google-adsense-account" content="ca-pub-XXXX">` in `<head>`**
  (This is how Google verifies you own the site)

---

## 🟢 RECOMMENDED (Improves approval speed)

- [ ] **Google Search Console** set up:
  - Site verified
  - Sitemap submitted: `https://toolhub.app/sitemap.xml`
  - At least 50+ pages indexed

- [ ] **Google Analytics 4** installed (shows Google you have real traffic)

- [ ] Site has been live and indexed for **3+ months**

- [ ] Navigation is clear — every page reachable from the homepage within 2 clicks

- [ ] Footer links work: Privacy, Terms, About, Contact

- [ ] Breadcrumbs present on all deep pages (✓ already in your code)

- [ ] No full-screen interstitials or popups that block content

- [ ] Cookie consent banner is shown (✓ `CookieConsent` component present)

---

## 🔵 TECHNICAL SEO (For fast indexing after approval)

- [ ] `sitemap.xml` returns 200 at: `https://toolhub.app/sitemap.xml`

- [ ] `robots.txt` allows `Mediapartners-Google` (✓ in updated `robots.ts`)

- [ ] JSON-LD structured data on:
  - Homepage (Organization + WebSite ✓)
  - Tool pages (SoftwareApplication ✓)
  - Blog posts (BlogPosting ✓)
  - Tool + blog pages (BreadcrumbList ✓)
  - Tool pages (FAQPage ✓)

- [ ] Open Graph tags on every page (✓ in layout.tsx)

- [ ] Twitter Card tags on every page (✓ in layout.tsx)

- [ ] Canonical URLs on every page (✓ in generateMetadata)

- [ ] `og-default.png` image exists at `/public/og-default.png`
  - Dimensions: 1200×630 pixels
  - Contains site name "ToolHub" and tagline
  - Clean, professional design

---

## 📋 Final Checks Before Clicking "Apply"

1. Open `https://toolhub.app` in an incognito window — does it look professional?
2. Click through 5–6 random tool pages — do they all work?
3. Read 2–3 blog posts — is the content genuinely useful?
4. Check `https://toolhub.app/privacy` — is the privacy policy complete and specific?
5. Run PageSpeed Insights: `https://pagespeed.web.dev/` — do you score 80+ on mobile?
6. Check Google Search Console → Coverage — are 30+ pages indexed?

If all 6 checks pass ✅ → apply for AdSense.

---

## ⏱ Timeline Expectations

| Stage | Typical Duration |
|-------|-----------------|
| AdSense application submitted | Day 0 |
| Google crawls your site | 3–7 days |
| First review decision | 1–3 weeks |
| If rejected: fix issues, reapply | Wait 1 month |
| If approved: first ad revenue | Within 24h of enabling ads |
| First payment (£70 threshold) | ~3–6 months for new sites |

---

*Remember: AdSense approval is about content quality and policy compliance. A site with 25 well-written, original blog posts and 30 working tools will almost always be approved.*
