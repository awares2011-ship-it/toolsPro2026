# ToolHub — Ad Placement Strategy
## Complete Guide for AdSense Approval + Maximum Revenue

---

## Ad Slot Map

| Slot Constant        | Location                            | Format                   | Lazy? | Notes                                  |
|----------------------|-------------------------------------|--------------------------|-------|----------------------------------------|
| `HOME_LEADERBOARD`   | Homepage — below hero grid          | Leaderboard (728×90)     | No    | Above-fold, loads immediately          |
| `TOOL_BELOW`         | Tool page — below tool output       | Horizontal (responsive)  | Yes   | User just used the tool = high intent  |
| `BLOG_MID`           | Blog post — after 2nd H2 heading    | Rectangle (300×250)      | Yes   | Injected automatically by renderer     |
| `BLOG_SIDEBAR`       | Blog + tool pages — right sidebar   | Rectangle (300×250)      | Yes   | Sticky position on desktop             |
| `FOOTER_BANNER`      | All pages — above footer            | Leaderboard (970×90)     | Yes   | Last touchpoint before user leaves     |
| `BLOG_LIST_MID`      | Blog list page — between card rows  | Horizontal (responsive)  | Yes   | Every 6 cards on /blog                 |

---

## Page-by-Page Breakdown

### Homepage (`/`)
```
[HERO — search + categories]
[TOOL GRID]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  HOME_LEADERBOARD (728×90, lazy=false)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[RECENT BLOG POSTS]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FOOTER_BANNER (970×90, lazy=true)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[FOOTER]
```
**Max ads**: 2. Keeps the homepage clean for AdSense approval review.

---

### Tool Page (`/tools/[id]`)
```
[BREADCRUMB]
[TOOL TITLE + DESCRIPTION]
[BADGE ROW: private · instant · mobile]

[TOOL UI PANEL]  ←→  [SIDEBAR: About this tool]
                 ←→  [SIDEBAR_AD — 300×250]
                 ←→  [RELATED TOOLS]
━━━━━━━━━━━━━━━━━━━━━
  TOOL_BELOW (horizontal, lazy=true)
━━━━━━━━━━━━━━━━━━━━━
[HOW TO USE section]
[FAQ section ← triggers rich results]
[RELATED BLOG POSTS]
━━━━━━━━━━━━━━━━━━━━━
  FOOTER_BANNER
━━━━━━━━━━━━━━━━━━━━━
[FOOTER]
```
**Max ads**: 3 (sidebar + below tool + footer).

---

### Blog Post (`/blog/[id]`)
```
[BREADCRUMB]
[CATEGORY BADGE · READ TIME · DATE · AUTHOR]
[H1 TITLE]
[LEAD PARAGRAPH]

[ARTICLE BODY: H2, paragraphs...]
[ARTICLE BODY: H2, paragraphs...]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ← after 2nd H2
  BLOG_MID (300×250, lazy=true)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ARTICLE BODY continues...]
[TAGS]
[AUTHOR CARD]

SIDEBAR (desktop only):
  - Related Tool CTA box
  - SIDEBAR_AD (300×250, lazy=true)
  - Related articles
━━━━━━━━━━━━━━━━━━━━━
  FOOTER_BANNER
━━━━━━━━━━━━━━━━━━━━━
[FOOTER]
```
**Max ads**: 3 (mid article + sidebar + footer).

---

### Blog List (`/blog`)
```
[H1 HEADING]
[Blog card row 1-6]
━━━━━━━━━━━━━━━━━━━━━
  BLOG_LIST_MID (horizontal, lazy=true)
━━━━━━━━━━━━━━━━━━━━━
[Blog card row 7-12...]
━━━━━━━━━━━━━━━━━━━━━
  FOOTER_BANNER
━━━━━━━━━━━━━━━━━━━━━
[FOOTER]
```

---

## CLS (Cumulative Layout Shift) Rules

**This is critical for both AdSense approval and Core Web Vitals.**

Every `<AdBanner>` wrapper reserves height BEFORE the ad loads using:
```tsx
style={{ minHeight: FORMAT_MIN_HEIGHT[format] }}
```

Reserved heights:
- `leaderboard` / `horizontal` → **90px**
- `rectangle` → **250px**
- `vertical` → **600px**

This prevents the page from "jumping" when ads load, keeping your CLS score under 0.1.

---

## Revenue Optimisation Tips

1. **Responsive ads everywhere**: Use `format="auto"` or `format="horizontal"` for most slots — Google fills the best-paying size automatically.

2. **Auto ads**: After your account is approved for a few months, consider enabling AdSense Auto Ads in addition to manual placements. This can find high-value spots you missed.

3. **Ad unit naming**: Name your ad units descriptively in AdSense dashboard (e.g., "ToolHub - Tool Below - Horizontal") to track performance per placement.

4. **Sticky sidebar**: Make the `BLOG_SIDEBAR` ad sticky on desktop (`position: sticky; top: 80px`) — it follows the reader and gets more viewable impressions, which pays more.

5. **Page RPM > slot CTR**: Focus on pages with >1,000 words (blog posts) — they earn higher RPM from Google because ads are more contextually matched.

---

## AdSense Policy Checklist

### Before Applying
- [ ] Site has been live for at least 3 months (recommended; not required)
- [ ] `Privacy Policy` page exists at `/privacy` — mentions cookies and advertising
- [ ] `Terms of Service` page exists at `/terms`
- [ ] `About` page exists at `/about` — explains what the site is
- [ ] `Contact` page exists at `/contact` — includes real email address
- [ ] No placeholder content ("Lorem ipsum", "coming soon" pages)
- [ ] All tool pages have real, working tool implementations
- [ ] All blog posts are at least 800 words
- [ ] All blog posts are original content (no copy-paste)
- [ ] No broken links (run: `npx broken-link-checker https://toolhub.app`)
- [ ] Site is mobile-responsive (test at: web.dev/measure)
- [ ] Core Web Vitals pass (LCP < 2.5s, CLS < 0.1, FID < 100ms)
- [ ] HTTPS is enabled on Firebase Hosting (it is by default)
- [ ] `<meta name="google-adsense-account" content="ca-pub-XXXX">` is in `<head>`
- [ ] Sitemap is submitted to Google Search Console
- [ ] At least 20 blog posts are indexed by Google
- [ ] At least 10 tool pages are indexed by Google

### Things That Get You Rejected
- ❌ Under-construction or empty pages
- ❌ Duplicate content from other sites
- ❌ No legal pages (privacy/terms)
- ❌ No real contact information
- ❌ Misleading navigation
- ❌ Content that violates Google policies (no hate speech, adult content, etc.)
- ❌ Too many 404 errors
- ❌ Very slow page load (LCP > 4s)

---

## How to Apply

1. Go to https://adsense.google.com/start
2. Click "Get Started" → sign in with your Google account
3. Enter your site URL: `https://toolhub.app`
4. Copy the AdSense verification meta tag they give you
5. Paste it into `layout.tsx` → `<meta name="google-adsense-account" content="ca-pub-XXXX">`
6. Deploy the updated site to Firebase
7. Click "Done, I've placed the code" in AdSense
8. Wait 2–4 weeks for review
9. Once approved: uncomment the `<Script>` tag in `layout.tsx` and replace all `XXXXXXXXXX` slot IDs

---

*Last updated: 2026*
