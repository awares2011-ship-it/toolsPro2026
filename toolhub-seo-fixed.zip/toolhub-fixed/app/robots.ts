import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      // Allow all well-behaved bots (including AI crawlers for discovery)
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/api/',      // no API routes to index
          '/_next/',    // Next.js internals
          '/static/',   // static assets
        ],
      },
      // AI crawlers allowed — they drive referral traffic and citations.
      // Remove individual entries below only if you have a specific legal
      // reason to opt out of a particular AI training programme.
      // { userAgent: 'GPTBot',           disallow: '/' },
      // { userAgent: 'ChatGPT-User',     disallow: '/' },
      // { userAgent: 'Google-Extended',  disallow: '/' },
      // { userAgent: 'anthropic-ai',     disallow: '/' },
      // { userAgent: 'ClaudeBot',        disallow: '/' },
    ],
    sitemap: 'https://toolhub.app/sitemap.xml',
    host:    'https://toolhub.app',
  }
}
