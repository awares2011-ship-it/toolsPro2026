import type { Metadata } from 'next'
import Script from 'next/script'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import CookieConsent from '@/components/CookieConsent'

// ─── Replace with your real AdSense publisher ID after approval ───────────
const PUBLISHER_ID = 'ca-pub-XXXXXXXXXX'
// ─────────────────────────────────────────────────────────────────────────

export const metadata: Metadata = {
  metadataBase: new URL('https://toolhub.app'),
  title: {
    default:  'ToolHub — Free Developer & Productivity Tools',
    template: '%s — ToolHub',
  },
  // Shortened to stay within 920px SERP width
  description: 'Free browser-based tools for developers, writers & SEO pros. JSON formatter, password generator, word counter, Base64 encoder, and 20+ more. No signup required.',
  keywords: ['free online tools', 'developer tools', 'json formatter', 'password generator', 'word counter', 'seo tools'],
  authors: [{ name: 'Breakout Trade', url: 'https://toolhub.app/about' }],
  creator: 'Breakout Trade',
  publisher: 'Breakout Trade',
  // ── Favicon / icons ───────────────────────────────────────────────────
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
      { url: '/favicon.ico', sizes: '48x48' },
    ],
    apple: '/apple-touch-icon.png',
  },
  // ── Open Graph (og:image + og:url fix) ───────────────────────────────
  openGraph: {
    siteName: 'ToolHub',
    type: 'website',
    locale: 'en_GB',
    url: 'https://toolhub.app',
    title: 'ToolHub — Free Developer & Productivity Tools',
    description: 'Free browser-based tools for developers, writers & SEO pros. JSON formatter, password generator, word counter, Base64 encoder, and 20+ more. No signup.',
    images: [
      {
        url: 'https://toolhub.app/og-image.png',
        width: 1200,
        height: 630,
        alt: 'ToolHub — Free Developer & Productivity Tools',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ToolHub — Free Developer & Productivity Tools',
    description: 'Free browser-based tools for developers, writers & SEO pros. No signup required.',
    images: ['https://toolhub.app/og-image.png'],
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  verification: {
    // ── Add your Google Search Console verification token below ──
    // google: 'YOUR_GSC_VERIFICATION_TOKEN',
  },
}

// Organization schema for Google rich results
const orgSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'ToolHub',
  alternateName: 'Breakout Trade',
  url: 'https://toolhub.app',
  logo: 'https://toolhub.app/icon.png',
  contactPoint: {
    '@type': 'ContactPoint',
    email: 'breakouttradeapp@gmail.com',
    contactType: 'customer support',
    availableLanguage: 'English',
  },
  sameAs: [],
}

const websiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: 'ToolHub',
  url: 'https://toolhub.app',
  description: 'Free browser-based tools for developers, writers, and SEO professionals.',
  potentialAction: {
    '@type': 'SearchAction',
    target: 'https://toolhub.app/?q={search_term_string}',
    'query-input': 'required name=search_term_string',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* ── JSON-LD structured data ───────────────────────────────────── */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
        />

        {/* ── llms.txt reference for AI discoverability ─────────────────── */}
        <link rel="ai-content-policy" href="https://toolhub.app/llms.txt" />

        {/* ── Google AdSense verification ───────────────────────────────────
            Step 1: Uncomment the meta tag below when applying for AdSense.
            Step 2: After approval, uncomment the Script tag in <body>.
            Replace ca-pub-XXXXXXXXXX with your real publisher ID.
        ──────────────────────────────────────────────────────────────────── */}
        {/* <meta name="google-adsense-account" content={PUBLISHER_ID} /> */}
      </head>
      <body className="flex flex-col min-h-screen">

        {/* ── Skip-to-content link (Accessibility / WCAG 2.1) ──────────────
            Visually hidden until focused — helps keyboard and screen-reader
            users jump past the navigation directly to the main content.
        ──────────────────────────────────────────────────────────────────── */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-[9999] focus:bg-green-600 focus:text-white focus:px-4 focus:py-2 focus:rounded-lg focus:text-sm focus:font-semibold"
        >
          Skip to main content
        </a>

        {/* ── Google AdSense Script ─────────────────────────────────────────
            Uncomment AFTER your AdSense account is approved.
            strategy="afterInteractive" keeps Core Web Vitals scores healthy.
        ──────────────────────────────────────────────────────────────────── */}
        {/* <Script
          async
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${PUBLISHER_ID}`}
          crossOrigin="anonymous"
          strategy="afterInteractive"
        /> */}

        <Header />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer />
        <CookieConsent />
      </body>
    </html>
  )
}
