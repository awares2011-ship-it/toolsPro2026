import type { Metadata } from 'next'
import HomepageClient from '@/components/HomepageClient'
import { TOOLS, CATEGORIES } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'

export const metadata: Metadata = {
  title: 'ToolHub — Free Developer & Productivity Tools',
  description: 'Free browser-based tools for developers, writers & SEO pros. JSON formatter, password generator, word counter, Base64 encoder, and 20+ more. No signup required.',
  alternates: { canonical: 'https://toolhub.app' },
  openGraph: {
    url: 'https://toolhub.app',
    images: [
      {
        url: 'https://toolhub.app/og-image.png',
        width: 1200,
        height: 630,
        alt: 'ToolHub — Free Developer & Productivity Tools',
      },
    ],
  },
}

export default function HomePage() {
  return (
    <HomepageClient
      tools={TOOLS}
      categories={CATEGORIES}
      blogs={BLOGS.slice(0, 6)}
    />
  )
}
