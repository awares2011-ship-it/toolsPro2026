'use client'
import { useEffect, useRef } from 'react'

// ─── Replace with your real AdSense publisher ID after approval ───────────
const PUBLISHER_ID = 'ca-pub-XXXXXXXXXX'
// ─────────────────────────────────────────────────────────────────────────

interface Props {
  slot: string
  format?: 'auto' | 'horizontal' | 'rectangle' | 'vertical'
  className?: string
}

declare global {
  interface Window { adsbygoogle: unknown[] }
}

export default function AdBanner({ slot, format = 'auto', className = '' }: Props) {
  const ref = useRef<HTMLModElement>(null)

  useEffect(() => {
    try {
      const adsByGoogle = window.adsbygoogle || []
      adsByGoogle.push({})
      window.adsbygoogle = adsByGoogle
    } catch {}
  }, [])

  return (
    <div className={`overflow-hidden text-center ${className}`} aria-label="Advertisement">
      <ins
        ref={ref}
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client={PUBLISHER_ID}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
    </div>
  )
}
