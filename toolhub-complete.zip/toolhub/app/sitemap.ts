import type { MetadataRoute } from 'next'
import { TOOLS } from '@/lib/tools'
import { CATEGORIES } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'

const BASE = 'https://toolhub.app'

export default function sitemap(): MetadataRoute.Sitemap {
  const staticPages: MetadataRoute.Sitemap = [
    { url: BASE,              lastModified: new Date(), changeFrequency: 'daily',   priority: 1.0 },
    { url: `${BASE}/blog`,    lastModified: new Date(), changeFrequency: 'weekly',  priority: 0.9 },
    { url: `${BASE}/about`,   lastModified: new Date(), changeFrequency: 'monthly', priority: 0.6 },
    { url: `${BASE}/contact`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
    { url: `${BASE}/privacy`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.4 },
    { url: `${BASE}/terms`,   lastModified: new Date(), changeFrequency: 'monthly', priority: 0.4 },
  ]

  const toolPages: MetadataRoute.Sitemap = TOOLS.map(t => ({
    url: `${BASE}/tools/${t.id}`,
    lastModified: new Date(),
    changeFrequency: 'monthly',
    priority: 0.85,
  }))

  const categoryPages: MetadataRoute.Sitemap = CATEGORIES.map(c => ({
    url: `${BASE}/tools/category/${c.id}`,
    lastModified: new Date(),
    changeFrequency: 'weekly',
    priority: 0.75,
  }))

  const blogPages: MetadataRoute.Sitemap = BLOGS.map(b => ({
    url: `${BASE}/blog/${b.id}`,
    lastModified: new Date(b.publishDate),
    changeFrequency: 'monthly',
    priority: 0.7,
  }))

  return [...staticPages, ...toolPages, ...categoryPages, ...blogPages]
}
