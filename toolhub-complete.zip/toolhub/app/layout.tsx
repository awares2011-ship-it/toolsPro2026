import type { Metadata } from 'next'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import CookieConsent from '@/components/CookieConsent'

// ─── Replace with your real AdSense publisher ID ─────────────────────────
const PUBLISHER_ID = 'ca-pub-XXXXXXXXXX'
// ─────────────────────────────────────────────────────────────────────────

export const metadata: Metadata = {
  metadataBase: new URL('https://toolhub.app'),
  title: {
    default:  'ToolHub — Free Developer & Productivity Tools',
    template: '%s — ToolHub',
  },
  description: 'Free, instant, browser-based tools for developers, writers, and SEO professionals. JSON formatter, password generator, word counter, and 20+ more. No signup required.',
  keywords: ['free online tools', 'developer tools', 'json formatter', 'password generator', 'word counter', 'seo tools'],
  openGraph: {
    siteName: 'ToolHub',
    type: 'website',
    locale: 'en_GB',
  },
  twitter: { card: 'summary_large_image' },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Google AdSense verification — add AFTER approval */}
        {/* <meta name="google-adsense-account" content={PUBLISHER_ID} /> */}
      </head>
      <body className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-1">
          {children}
        </main>
        <Footer />
        <CookieConsent />
      </body>
    </html>
  )
}
