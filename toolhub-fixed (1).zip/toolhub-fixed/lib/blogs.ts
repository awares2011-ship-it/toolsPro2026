export interface Blog {
  id: string
  title: string
  description: string
  relatedTool: string
  category: string
  color: string
  readTime: number
  publishDate: string
  content: string
  relatedBlogs: string[]
  tags: string[]
}

export const BLOGS: Blog[] = [
  {
    id: 'what-is-json-formatter',
    title: 'What is a JSON Formatter? The Complete Guide',
    description: 'Learn what JSON is, why formatting matters, and how a JSON formatter boosts developer productivity.',
    relatedTool: 'json-formatter',
    category: 'Developer',
    color: 'teal',
    readTime: 7,
    publishDate: '2024-11-01',
    tags: ['json', 'developer', 'formatting', 'api'],
    relatedBlogs: ['how-to-format-json', 'what-is-base64', 'csv-json-conversion'],
    content: `JSON (JavaScript Object Notation) is the de facto data interchange format of the modern web. From REST APIs to configuration files, JSON is everywhere — and keeping it readable is essential for developer productivity. Whether you are a beginner just learning about APIs or a senior engineer debugging a production issue, a JSON formatter is a tool you will reach for every single day.

## What is JSON?

JSON is a lightweight, text-based format for storing and transporting structured data. It uses human-readable key-value pairs, arrays, and nested objects that map naturally to data structures in virtually every programming language. A simple JSON object looks like this:

\`\`\`json
{
  "name": "ToolHub",
  "version": 2,
  "tools": ["JSON Formatter", "Word Counter", "Password Generator"],
  "free": true
}
\`\`\`

JSON was derived from JavaScript object literal syntax but is language-independent. Python, Java, Go, Ruby, PHP, and hundreds of other languages all have native JSON libraries, making it the universal language of data exchange on the web.

## Why JSON Became the Standard

Before JSON, XML dominated as the web data format. While XML is powerful, it is verbose and harder to read. A simple list of three user names in XML might span fifteen lines; in JSON, it is four. This combination of readability and compactness, along with its tight integration with JavaScript, made JSON the clear winner.

Today, virtually every public REST API returns JSON. The Twitter API, GitHub API, Google Maps API, Stripe payment API — they all speak JSON. If you work in web development, you are reading and writing JSON every day.

## Why Do You Need a JSON Formatter?

When JSON is transmitted over the internet, it is almost always minified — all whitespace stripped to reduce payload size. A typical API response might look like this:

\`{"user":{"id":1,"name":"Alice","email":"alice@example.com","roles":["admin","editor"],"settings":{"theme":"dark","notifications":true}}}\`

That is valid JSON, but practically unreadable. A JSON formatter adds proper indentation, line breaks, and hierarchical structure back to minified JSON, turning that dense line into a well-organised, human-readable document.

### Key Benefits of Using a JSON Formatter

**Debugging APIs**: When your fetch request returns a wall of compressed text, a formatter instantly makes the response comprehensible. You can see exactly what data you received and spot missing fields immediately.

**Error detection and validation**: Most formatters also validate JSON syntax. If you have a missing comma, an extra bracket, or unquoted keys, the formatter tells you exactly where the problem is — often with a line number and character position.

**Code reviews**: Reviewing JSON changes in pull requests is dramatically easier when the JSON is properly formatted. Minified JSON diffs are nearly impossible to review meaningfully.

**Configuration files**: Many applications use JSON for configuration — package.json, .eslintrc.json, tsconfig.json. Keeping these files well-formatted makes them much easier to maintain.

**Documentation**: When writing API documentation or tutorials, formatted JSON examples are far clearer for readers than minified blobs.

## How a JSON Formatter Works

Under the hood, a JSON formatter does two things: it parses the input and re-serialises it with formatting. In JavaScript, this is achieved with two native functions:

1. JSON.parse(input) — converts the JSON string into a JavaScript object
2. JSON.stringify(object, null, 2) — converts the object back to a string with 2-space indentation

The second argument to JSON.stringify (null) is a replacer function not used here, and the third argument (2) is the number of spaces for indentation. Some formatters offer 2-space, 4-space, or tab indentation options.

If JSON.parse throws a SyntaxError, the formatter catches it and reports the problem to the user rather than crashing silently.

ToolHub's JSON Formatter runs entirely in your browser — no data is ever sent to a server. This makes it safe to use with sensitive API keys, private data, or production credentials.

## Common JSON Errors and How to Fix Them

**Missing quotes on keys**: JSON requires all keys to be double-quoted strings. {name: "Alice"} is invalid. The correct form is {"name": "Alice"}.

**Trailing commas**: Unlike modern JavaScript, JSON does not allow trailing commas after the last item in an object or array. [1, 2, 3,] will throw a parse error.

**Single quotes**: JSON only accepts double quotes for both keys and string values. {'key': 'value'} is invalid.

**Undefined and NaN**: These JavaScript-specific values do not exist in the JSON specification. Use null instead.

**Comments**: JSON does not support comments. If you need comments in a configuration file, consider JSONC or YAML instead.

## JSON vs. Other Data Formats

| Format | Human Readable | Comments | Schema | Use Case |
|--------|:--------------:|:--------:|:------:|----------|
| JSON   | Yes | No | JSON Schema | REST APIs, configs |
| YAML   | Yes | Yes | Yes | DevOps configs |
| XML    | Verbose | Yes | XSD | Legacy systems |
| CSV    | Yes | No | No | Tabular data |
| TOML   | Yes | Yes | No | App configuration |

## Tips for Working with JSON Daily

Always format JSON before adding it to documentation or sharing it with colleagues. Use a linter like eslint-plugin-json to automatically format JSON files in your editor. When building APIs, return pretty-printed JSON in development mode and minified JSON in production. Keep your package.json and other config files well-formatted — they are important project documents your whole team reads.

## Conclusion

A JSON formatter is one of the most-used tools in a developer's toolkit. Whether you are debugging an API response, reviewing a pull request, or cleaning up a messy configuration file, a fast and reliable formatter saves significant time and mental energy. ToolHub's free, instant, in-browser JSON Formatter requires no signup, stores no data, and works on any device — bookmark it today.`,
  },
  {
    id: 'how-to-format-json',
    title: 'How to Format JSON: Best Practices for Clean, Readable Data',
    description: 'A complete guide to JSON formatting best practices for developers, including indentation, naming conventions, and validation.',
    relatedTool: 'json-formatter',
    category: 'Developer',
    color: 'teal',
    readTime: 7,
    publishDate: '2024-11-05',
    tags: ['json', 'best practices', 'formatting', 'developer'],
    relatedBlogs: ['what-is-json-formatter', 'csv-json-conversion', 'jwt-explained'],
    content: `Formatting JSON consistently and correctly is a fundamental skill for web developers. Clean JSON improves readability, reduces bugs, and makes collaboration far easier. This guide covers everything from indentation choices to naming conventions, schema validation, and tooling that keeps your JSON spotless across a team.

## The Basics: Indentation and Structure

The most visible aspect of JSON formatting is indentation. The two dominant conventions are 2-space and 4-space indentation. Neither is objectively correct — what matters is consistency within a project.

2-space indentation is the default for most Node.js and JavaScript projects. It produces compact files that are easy to read without excessive horizontal scroll on nested objects.

4-space indentation is preferred in Python-heavy projects and some enterprise environments where deeper nesting must remain readable.

Tab indentation exists but is less common in JSON since JSON is often generated programmatically and tabs can behave inconsistently across editors.

For project configuration files like package.json or .prettierrc, the built-in tools typically enforce their own format — follow those rather than imposing your own.

## Naming Conventions for JSON Keys

JSON keys are strings, which means technically anything goes. In practice, there are four common naming styles:

**camelCase** (firstName, createdAt) — The JavaScript standard. Best for JSON consumed directly by JavaScript frontends.

**snake_case** (first_name, created_at) — Common in Python and Ruby APIs. Readable but inconsistent with JS variable names.

**PascalCase** (FirstName, CreatedAt) — Rare in JSON, more common in C# / .NET environments.

**kebab-case** (first-name, created-at) — Avoided in JSON because hyphens cannot be used in JavaScript identifier names without bracket notation.

The key rule is: pick one convention and apply it uniformly across your entire API. Mixed conventions create bugs and confusion. If you are consuming a third-party API that uses snake_case, you can use middleware to convert keys to camelCase before they reach your frontend code.

## Ordering Keys for Readability

JSON does not specify key ordering — parsers may return keys in any order. However, for human-readable files, a consistent ordering convention greatly improves comprehension:

1. Identifier fields first (id, type, name)
2. Required fields before optional fields
3. Timestamps last (createdAt, updatedAt, deletedAt)
4. Nested objects at the end

Many JSON formatters include an option to sort keys alphabetically. This is useful for diffs — alphabetically sorted keys make it obvious when a field was added or removed.

## Handling Null and Optional Fields

A frequent question is whether to include fields with null values or omit them entirely. Both approaches are valid, but each has trade-offs.

**Include null fields**: Your API response has a consistent shape on every call. Consumers know what fields to expect and can write simple, predictable code.

**Omit null fields**: Smaller payload size. Useful when most fields are optional and only a few are typically populated.

A hybrid approach works well: always include required identifier and status fields even if null, but omit optional descriptive fields when not set.

## Validating JSON with a Schema

JSON Schema is a powerful tool for validating that JSON data conforms to an expected structure. A simple schema looks like this:

\`\`\`json
{
  "$schema": "http://json-schema.org/draft-07/schema",
  "type": "object",
  "required": ["id", "name", "email"],
  "properties": {
    "id": { "type": "integer" },
    "name": { "type": "string", "minLength": 1 },
    "email": { "type": "string", "format": "email" },
    "age": { "type": "integer", "minimum": 0, "maximum": 120 }
  }
}
\`\`\`

Libraries like ajv (JavaScript) and jsonschema (Python) can validate data against a schema at runtime, catching invalid data before it reaches your database or causes hard-to-debug errors downstream.

## JSON in Code Reviews

One of the highest-value applications of consistent JSON formatting is in code reviews. When configuration files, fixtures, or mock API responses are committed to version control, well-formatted JSON makes diffs meaningful. A change to a single value shows up as one changed line, not a complete file rewrite.

Use tools like Prettier or ESLint with eslint-plugin-json to automatically format JSON files on save or as a pre-commit hook. This eliminates formatting debates in pull requests entirely.

## Minification for Production

While formatted JSON is ideal for development, minified JSON is better for production API responses. Removing all whitespace from a 50KB JSON response can reduce it to 30KB — a 40% saving that adds up significantly at scale.

Most backend frameworks offer a "pretty print" mode for development and minified output for production. In Express.js, setting app.set('json spaces', 2) in development and leaving it unset in production handles this automatically.

## Practical Tips for Daily JSON Work

Keep a JSON formatter bookmarked for quick debugging. When pasting JSON into documentation or chat messages, always format it first — raw minified JSON is inconsiderate to readers. Use JSON.stringify(data, null, 2) in console.log calls during debugging to get readable output. In VS Code, the built-in "Format Document" command formats JSON files automatically.

## Working with Deeply Nested JSON

Deep nesting is a JSON anti-pattern. If you find yourself with 5 or more levels of nesting, consider whether the data model should be flattened or split into separate API endpoints. Deeply nested JSON is hard to read, hard to query, and often indicates an overly complex data model. A good rule of thumb is to keep nesting to 3 levels maximum for readability.

## JSON Comments: A Workaround

Standard JSON does not support comments, which is a pain point for configuration files. Common workarounds include using a dedicated key like "_comment" for documentation purposes, switching to JSONC (JSON with Comments) supported by VS Code and TypeScript configs, or migrating to YAML for config files where comments add significant value.

## Conclusion

Good JSON formatting is a simple discipline with outsized rewards. It makes debugging faster, collaboration smoother, and code reviews more productive. By adopting consistent conventions for indentation, key naming, null handling, and schema validation, you write cleaner APIs and more maintainable applications. Use ToolHub's JSON Formatter anytime you need to quickly format or validate JSON — no setup, no friction, just clean results.`,
  },
  {
    id: 'password-security-guide',
    title: 'The Complete Guide to Password Security in 2024',
    description: 'Everything you need to know about creating strong passwords, using password managers, and protecting your accounts online.',
    relatedTool: 'password-generator',
    category: 'Security',
    color: 'coral',
    readTime: 8,
    publishDate: '2024-11-08',
    tags: ['password', 'security', 'cybersecurity', 'online safety'],
    relatedBlogs: ['md5-sha256-difference', 'what-is-uuid', 'jwt-explained'],
    content: `Password security is the first and most important line of defence against account compromise, identity theft, and data breaches. Despite decades of warnings, password reuse and weak passwords remain the most common causes of security incidents worldwide. This guide covers everything you need to know to protect yourself and your users in 2024.

## Why Passwords Are Still Critical

You might assume that modern technology — biometrics, hardware keys, two-factor authentication — has made passwords obsolete. It has not. Passwords remain the primary authentication mechanism for the vast majority of online accounts. Even when you use Google or Apple to sign in, there is a password behind that account. Understanding how to create and manage strong passwords is non-negotiable.

The scale of the problem is staggering. The "Have I Been Pwned" database tracks billions of compromised credentials from thousands of data breaches. Studies consistently show that the most common passwords include "123456", "password", and "qwerty" — choices that an attacker can crack in under a second.

## What Makes a Password Strong?

Security researchers and standards bodies, including NIST (the US National Institute of Standards and Technology), have updated their guidance significantly over the past decade. Here is what actually matters:

**Length is the most important factor.** A 16-character password of random words is far stronger than an 8-character password with complex symbols. Every additional character multiplies the number of possible combinations exponentially. A 12-character password has roughly 95^12 possible combinations — that is over 540 quadrillion possibilities.

**Randomness matters more than complexity.** The old advice to replace letters with numbers (like "p@ssw0rd") is largely useless — attackers account for these substitutions in their dictionary attacks. True randomness, achieved by a password generator, is far harder to crack than a human-constructed complex password.

**Avoid predictable patterns.** Birthdates, pet names, favourite sports teams, and keyboard patterns like "qwerty123" are among the first things attackers try. Personal information is often available through social media.

**Never reuse passwords.** If any service you use suffers a breach, attackers will immediately try those credentials on other popular services. This attack, known as credential stuffing, is responsible for the vast majority of account compromises.

## The NIST Password Guidelines

NIST SP 800-63B changed the conventional wisdom on passwords. Key recommendations include:

- Minimum length of 8 characters for user-created passwords (longer is strongly encouraged)
- No mandatory complexity rules — forcing users to add symbols produces weaker passwords because users make predictable choices
- No mandatory periodic changes — unless there is evidence of compromise, frequent forced changes produce worse passwords
- Check against known breached password lists — block commonly used passwords
- Allow all printable characters including spaces — passphrases are highly recommended

## Password Managers: The Real Solution

The only practical solution to the password problem is a password manager. A good password manager generates a unique, random, long password for every account and stores it in an encrypted vault. You need to remember only one strong master password.

Leading password managers include Bitwarden (open source, free tier available), 1Password, Dashlane, and the built-in managers in Apple iCloud Keychain and Google Password Manager. All of these generate strong random passwords, auto-fill credentials on login forms, warn you about reused or compromised passwords, and sync across devices securely.

The security of a password manager depends on your master password and the security of the manager itself. Use a strong, unique passphrase as your master password — never use it anywhere else.

## Two-Factor Authentication

Even the strongest password can be compromised if a service has a server-side breach or if you are tricked by a phishing attack. Two-factor authentication (2FA) adds a critical second layer of protection.

**TOTP authenticator apps** (like Authy or Google Authenticator) generate time-based one-time codes. These are significantly more secure than SMS-based 2FA, which can be intercepted via SIM swapping attacks.

**Hardware security keys** (like YubiKey) provide the strongest 2FA available. They are phishing-resistant because they verify the domain of the site before responding.

**SMS 2FA** is better than no 2FA but should not be relied upon for high-value accounts due to SIM swapping risks.

Enable 2FA on every account that supports it, prioritising email, banking, social media, and any account linked to a payment method.

## Password Requirements for Developers

If you are building an application that handles user authentication, you are responsible for implementing password security correctly:

**Hash passwords with bcrypt, scrypt, or Argon2** — never MD5 or SHA256, which are too fast and unsuitable for password hashing. These algorithms are intentionally slow, making brute-force attacks impractical.

**Use a unique salt per password** — good libraries handle this automatically.

**Implement rate limiting and account lockout** to prevent brute-force attacks.

**Check against breached password lists** using the HaveIBeenPwned API at registration time.

**Never store plaintext passwords** or use reversible encryption.

## How to Audit Your Current Passwords

Start by checking whether your email addresses have been compromised at haveibeenpwned.com. Then review your accounts in your password manager — most show a security audit highlighting reused, weak, or compromised passwords. Prioritise changing passwords for your email account, your bank, your password manager, and social media.

## Passphrases: A Human-Friendly Alternative

A passphrase is a sequence of random words — like "correct-horse-battery-staple" — that is long enough to be secure but easier to remember than a string of random characters. At four random words, a passphrase has roughly 2^51 combinations using a 7776-word wordlist (the Diceware list). That is more than sufficient for most purposes.

Passphrases work best as master passwords for password managers, encryption keys, and other credentials you must type regularly. For individual website accounts, still use a password manager with random generated passwords.

## Conclusion

Password security is not glamorous, but it is foundational. A strong, unique password for every account, managed by a reputable password manager, with 2FA enabled on critical accounts, will protect you against the vast majority of attacks. Use ToolHub's Password Generator to create cryptographically random passwords of any length and complexity — entirely in your browser, with zero data stored.`,
  },
  {
    id: 'what-is-base64',
    title: 'What is Base64 Encoding? A Plain-English Explanation',
    description: 'Understand Base64 encoding and decoding — what it is, why it exists, when to use it, and common use cases in web development.',
    relatedTool: 'base64-encoder',
    category: 'Developer',
    color: 'emerald',
    readTime: 7,
    publishDate: '2024-11-12',
    tags: ['base64', 'encoding', 'developer', 'web'],
    relatedBlogs: ['what-is-json-formatter', 'url-encoding-explained', 'jwt-explained'],
    content: `Base64 is one of those technologies that developers encounter constantly but rarely stop to understand deeply. You see it in image data URIs, JWT tokens, email attachments, and API authentication headers. This guide explains what Base64 encoding is, how it works, when to use it, and equally important — when not to use it.

## What is Base64?

Base64 is a binary-to-text encoding scheme that converts arbitrary binary data into a string of 64 printable ASCII characters. The 64 characters used are: A-Z (26), a-z (26), 0-9 (10), plus (+) and slash (/), with equals sign (=) used as padding. Some variants, like Base64URL, replace + with - and / with _ to make the output safe for use in URLs.

The name "Base64" simply reflects that the encoding uses a 64-character alphabet — making it a base-64 numeral system, in the same way that our everyday counting is base-10 and computers use base-2 (binary).

## Why Does Base64 Exist?

The core problem Base64 solves is this: many communication protocols and systems were designed to handle text (specifically 7-bit ASCII), not arbitrary binary data. When you need to transmit binary data — like an image, a PDF, or an encrypted token — through a text-based channel, you need a way to represent that binary data using only printable text characters.

Common scenarios where this problem arises:

**Email (MIME encoding)**: Email was originally designed for 7-bit ASCII text. Attachments must be Base64-encoded to travel safely through email servers.

**HTML data URIs**: Embedding an image directly in HTML requires encoding the binary image data as text.

**JWT tokens**: The header and payload sections of JSON Web Tokens are Base64URL-encoded.

**HTTP Basic Authentication**: Credentials are Base64-encoded (though not encrypted) in the Authorization header.

**Cryptographic keys and certificates**: PEM format files (like SSL certificates) use Base64 to represent binary key data.

## How Base64 Encoding Works

Base64 takes 3 bytes (24 bits) of input and converts them to 4 Base64 characters (each representing 6 bits). This is the fundamental operation.

For example, the ASCII string "Man" has three bytes: 77, 97, 110. In binary: 01001101 01100001 01101110. Grouping into 6-bit chunks: 010011 010110 000101 101110. Converting each 6-bit group to its Base64 character: T, W, F, u. So "Man" encodes to "TWFu".

The encoding ratio is always 4/3 — Base64 output is approximately 33% larger than the input. For a 1 MB image, the Base64 string will be roughly 1.37 MB.

## Base64 Is Encoding, Not Encryption

This is the most important misconception to correct: Base64 is not encryption and provides zero security. It is trivially reversible. Anyone who sees a Base64 string can decode it in seconds using any of hundreds of free tools.

HTTP Basic Authentication sends your password as a Base64-encoded string in the header. This is completely readable to anyone who can intercept the request. This is why HTTPS is essential when using Basic Auth — TLS encrypts the entire request including headers.

If you need to protect data, use proper encryption (AES, RSA, etc.) — not Base64 encoding.

## Common Use Cases in Web Development

**Embedding images in CSS/HTML**: Small icons and UI elements can be embedded directly as data URIs, eliminating an extra HTTP request. The syntax is: url('data:image/png;base64,<encoded data>').

**Transmitting binary data in JSON**: JSON only supports text. If you need to include binary data (like an image or file) in a JSON API payload, Base64 encoding it is the standard approach.

**JWT tokens**: A JWT like eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOjF9.signature consists of three Base64URL-encoded sections separated by dots. You can decode the first two sections to see the header and payload (but decoding does not verify the signature).

**SSH and SSL keys**: The familiar "-----BEGIN RSA PRIVATE KEY-----" block contains Base64-encoded binary key data.

**HMAC and cryptographic signatures**: Many API authentication schemes use Base64-encoded HMAC signatures in request headers.

## Base64 in URLs: The URL-Safe Variant

Standard Base64 uses + and / characters, which have special meanings in URLs. Base64URL is a variant that replaces + with - and / with _ and omits the = padding, making it safe to use in query strings and URL path segments without percent-encoding.

This variant is used in JWTs, OAuth tokens, and many modern API authentication schemes.

## Performance Considerations

Base64 encoding and decoding are computationally cheap, but the 33% size overhead matters for performance-sensitive applications. For large binary payloads, consider whether binary transfer protocols (like multipart/form-data for file uploads) might be more appropriate than Base64 in JSON.

For embedded images, use Base64 data URIs only for small images (under 10-15 KB). Larger images are better served as separate files with proper HTTP caching headers.

## Decoding Base64: What You Can Learn

Decoding a Base64 string reveals the underlying data, which is useful for debugging. You can decode JWT payloads to inspect claims, decode Base64-encoded configuration values, or check what an API is actually sending in an encoded response field.

ToolHub's Base64 Encoder/Decoder works entirely in your browser — paste any text to encode it, or paste any Base64 string to decode it. It is especially useful when working with JWTs, API headers, or debugging data URIs.

## Base64 Variants at a Glance

There are several Base64 variants in use:

**Standard Base64**: Uses +, /, and = padding. Used in email and most non-URL contexts.

**Base64URL**: Uses -, _ instead of +, / and omits padding. Used in JWTs, OAuth, and URL contexts.

**Base64 for MIME**: Adds line breaks every 76 characters. Used in email attachments per the MIME standard.

**Modified Base64 for filenames**: Uses - and _ like Base64URL, designed for safe use in file and directory names.

Always check which variant an API or protocol expects before implementing Base64 handling.

## Conclusion

Base64 is a fundamental encoding used throughout web development, networking, and cryptography. Understanding what it is (a binary-to-text encoding), what it is not (encryption), and when to use it (transmitting binary through text channels) will make you a more confident developer. Bookmark ToolHub's Base64 tool for instant encoding and decoding whenever you need it.`,
  },
  {
    id: 'url-encoding-explained',
    title: 'URL Encoding Explained: What It Is and Why It Matters',
    description: 'A clear explanation of percent-encoding — what gets encoded, how to decode URLs, and common pitfalls in web development.',
    relatedTool: 'url-encoder',
    category: 'Developer',
    color: 'amber',
    readTime: 7,
    publishDate: '2024-11-15',
    tags: ['url', 'encoding', 'web', 'developer'],
    relatedBlogs: ['what-is-base64', 'what-is-json-formatter', 'slug-generator-guide'],
    content: `Every time you click a link, submit a form, or make an API request, URL encoding is working silently in the background. When you search for "cafe near me" in a search engine, the space and any accented characters get converted into percent-encoded sequences before the URL is sent to the server. Understanding URL encoding is essential for web developers, API designers, and anyone who works with web addresses.

## What is URL Encoding?

URL encoding (officially called "percent-encoding") is a mechanism for encoding information in a Uniform Resource Identifier (URI) in a way that is unambiguous and safe to transmit. URLs can only contain a limited set of safe characters — alphanumeric characters and a few symbols (-, _, ., ~). Any other character must be encoded.

Encoding works by replacing the character with a percent sign (%) followed by two hexadecimal digits representing the character's ASCII or UTF-8 byte value. For example:

- Space becomes %20
- @ becomes %40
- / becomes %2F
- The accented e in "cafe" becomes %C3%A9 (two bytes in UTF-8)
- & becomes %26

The term "URL encoding" is commonly used, but more precisely, the URI specification (RFC 3986) uses the term "percent-encoding".

## Which Characters Need to Be Encoded?

The URI specification divides characters into three groups:

**Reserved characters**: These have special syntactic meaning in URLs and must be encoded when they appear as data rather than structure. Examples include colon, slash, question mark, hash, brackets, at sign, and ampersand.

**Unreserved characters**: These are safe in any context and do not need encoding: A-Z, a-z, 0-9, hyphen, underscore, period, and tilde.

**Other characters**: Everything else (spaces, accented characters, non-Latin scripts, control characters) must be percent-encoded.

The critical distinction is between encoding URL components versus encoding entire URLs. A slash in a URL path is structural and should not be encoded. A slash appearing as data within a query parameter value must be encoded as %2F.

## URL Encoding vs. Query String Encoding

There is a subtle but important difference between general percent-encoding and application/x-www-form-urlencoded encoding (the format used by HTML form submissions).

In standard percent-encoding, spaces become %20. In form-urlencoded encoding (used in HTML forms and some older APIs), spaces are encoded as +. The encodeURIComponent() function in JavaScript uses %20, while form submissions use +.

This is a common source of bugs. When manually constructing query strings, always use encodeURIComponent() in JavaScript rather than encodeURI() (which does not encode characters like &, =, and ? that are structural in query strings).

## JavaScript URL Encoding Functions

JavaScript provides three relevant functions:

**encodeURIComponent(value)** — encodes a value to be safely embedded in a URL component (query param value, path segment). Encodes everything except alphanumeric characters and the following: hyphen, underscore, period, exclamation mark, tilde, asterisk, apostrophe, and parentheses. This is what you should use 90% of the time.

**encodeURI(uri)** — encodes a complete URL but leaves structural characters unencoded. Useful when encoding an entire URL that already has its structure intact.

**decodeURIComponent(encoded)** — decodes a percent-encoded string back to its original form.

Example usage:

\`\`\`javascript
const query = 'cafe latte & pastry'
const encoded = encodeURIComponent(query)
// Result: 'cafe%20latte%20%26%20pastry'
const url = 'https://example.com/search?q=' + encoded
\`\`\`

## Common URL Encoding Pitfalls

**Double encoding**: If you call encodeURIComponent on an already-encoded string, you will encode the percent signs too — %20 becomes %2520. Always decode before re-encoding to avoid this.

**Inconsistent space handling**: Some systems expect + for spaces in query strings, others expect %20. Know which your API uses.

**Non-ASCII characters**: URLs technically only support ASCII, but internationalized URLs use UTF-8 percent-encoding for paths and queries. Modern browsers handle this transparently, but backend code may need to normalise incoming URLs.

**Forgetting to encode path parameters**: Path parameters that contain slash, question mark, or hash characters must be encoded, or they will be interpreted as URL structure rather than data.

## URL Encoding in APIs

When building or consuming REST APIs, URL encoding is critical for query parameters. If you have an endpoint that accepts a search term parameter, special characters in the search term must be encoded.

HTTP libraries like Axios, fetch, and HTTPie handle encoding automatically if you pass parameters as objects rather than constructing query strings manually. This is the recommended approach as it eliminates encoding errors.

\`\`\`javascript
// Let the library handle encoding
const response = await fetch('/api/search?' + new URLSearchParams({
  q: 'C++ programming',
  sort: 'price:asc'
}))
// Produces: /api/search?q=C%2B%2B+programming&sort=price%3Aasc
\`\`\`

## Decoding URLs for Debugging

When debugging URL issues — perhaps an API request is failing or a redirect is going wrong — being able to quickly decode percent-encoded URLs is invaluable. A URL like https://example.com/search?q=caf%C3%A9%20latte&sort=price%3Aasc is much clearer when decoded to show the actual values.

ToolHub's URL Encoder/Decoder lets you instantly encode or decode any URL or component, helping you debug issues and understand what URLs actually contain.

## Internationalised URLs (IRI)

Internationalized Resource Identifiers (IRIs) extend URIs to allow Unicode characters directly in paths and queries, making URLs human-readable in non-Latin scripts. Browsers display IRIs in decoded form in the address bar, while the actual network request uses percent-encoded UTF-8 bytes.

This is why a Wikipedia URL for a Japanese article looks readable in your browser address bar but the underlying HTTP request uses percent-encoded bytes. Both representations refer to the same resource.

## Conclusion

URL encoding is a foundational web technology that prevents ambiguity and ensures data is transmitted safely through URLs. Understanding the difference between structural URL characters and data characters, using encodeURIComponent correctly in JavaScript, and knowing about the + versus %20 space encoding difference will save you significant debugging time. Use ToolHub's URL Encoder whenever you need to quickly encode or decode URL components.`,
  },
]

  {
    id: 'meta-tags-complete-guide',
    title: 'Meta Tags Complete Guide: SEO, Social Sharing & Best Practices',
    description: 'Everything web developers and SEO professionals need to know about HTML meta tags — title tags, descriptions, Open Graph, Twitter Cards, and more.',
    relatedTool: 'meta-tag-generator',
    category: 'SEO',
    color: 'pink',
    readTime: 9,
    publishDate: '2024-11-18',
    tags: ['meta tags', 'seo', 'html', 'open graph'],
    relatedBlogs: ['open-graph-guide', 'robots-txt-guide', 'keyword-density-seo'],
    content: `Meta tags are HTML elements that provide information about a web page to search engines, browsers, and social media platforms. Although they are invisible to users, they have an enormous impact on how pages appear in search results, how they look when shared on social media, and how browsers handle them. This guide covers every important meta tag you need to know.

## What Are Meta Tags?

Meta tags live inside the head section of an HTML document. They are not displayed on the page itself but are read by search engine crawlers, social media scrapers, and browser rendering engines. A minimal set of meta tags might look like this:

\`\`\`html
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Page Title — Site Name</title>
  <meta name="description" content="A concise description of the page.">
</head>
\`\`\`

## The Title Tag

While technically not a meta element, the title tag is the most important on-page SEO element. It appears as the clickable headline in search engine results pages and as the browser tab label.

Best practices for title tags:
- Keep them between 50-60 characters (Google truncates around 600px width, roughly 60 characters)
- Include your primary keyword near the beginning
- Make each page's title unique
- Use a separator (like a dash or pipe) between the page title and site name
- Write for humans first, then for search engines

Example: JSON Formatter — Free Online Tool | ToolHub

## The Description Meta Tag

The meta description is a brief summary of the page shown below the title in search results. While Google does not use it as a direct ranking factor, it significantly impacts click-through rates — a compelling description means more clicks.

Best practices:
- Keep descriptions between 150-160 characters
- Include your target keyword naturally
- Write a genuine, compelling summary — treat it as ad copy
- Make each page's description unique
- Include a call to action where natural

## Robots Meta Tag

The robots meta tag tells search engine crawlers how to treat a page. The default behaviour is to index the page and follow all links.

Common values:
- index, follow — Default, allow indexing and link following
- noindex, nofollow — Block the page entirely from search results
- noindex, follow — Do not index but still follow links
- index, nofollow — Index the page but do not follow its links

Use noindex for: duplicate content pages, search result pages, thank-you pages, internal tools, and staging environments.

## Viewport Meta Tag (Mobile Responsiveness)

The viewport meta tag controls how a page is displayed on mobile devices. Without it, mobile browsers render the page at desktop width and then scale it down, making text tiny.

\`\`\`html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
\`\`\`

This is non-negotiable for modern websites. Google uses mobile-first indexing, meaning it evaluates the mobile version of your page for ranking. A missing viewport tag will hurt both user experience and SEO.

## Charset Meta Tag

The charset declaration tells the browser how to interpret the text encoding of the page. Always use UTF-8, which supports all languages and symbols.

\`\`\`html
<meta charset="UTF-8">
\`\`\`

Place this as the very first element inside head — before the title tag — to ensure the browser uses the correct encoding when parsing the page title.

## Open Graph Tags for Social Sharing

Open Graph (OG) tags were introduced by Facebook and are now used by all major social platforms to generate link preview cards when pages are shared. Without OG tags, social platforms make their best guess at what image and text to show — usually with poor results.

\`\`\`html
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Page description for social sharing.">
<meta property="og:image" content="https://example.com/og-image.jpg">
<meta property="og:url" content="https://example.com/page">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Your Site Name">
\`\`\`

OG image requirements: Use an image at least 1200x630 pixels for best display across platforms. Keep important content away from edges as some platforms crop the image.

## Twitter Card Tags

Twitter has its own set of meta tags for customising how links appear in Twitter/X. Twitter will fall back to OG tags if Twitter-specific tags are absent, but explicit Twitter tags give you more control.

\`\`\`html
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Title">
<meta name="twitter:description" content="Description for Twitter sharing.">
<meta name="twitter:image" content="https://example.com/twitter-image.jpg">
<meta name="twitter:site" content="@yourtwitterhandle">
\`\`\`

Use summary_large_image for most pages (shows a large image preview). Use summary for pages without a meaningful visual image.

## Canonical Tag (Preventing Duplicate Content)

The canonical tag tells search engines which version of a page is the "official" version when multiple URLs serve similar content. This is critical for e-commerce sites, blogs with paginated archives, and pages accessible via multiple URL parameters.

\`\`\`html
<link rel="canonical" href="https://example.com/the-definitive-url/">
\`\`\`

Use canonical tags for: HTTP vs HTTPS versions, www vs non-www, URLs with tracking parameters, paginated pages, and product pages accessible via multiple category paths.

## Language and Regional Tags

For multilingual sites, the hreflang attribute tells Google which version of a page serves which language and region. This prevents the wrong language version from appearing in search results.

\`\`\`html
<link rel="alternate" hreflang="en" href="https://example.com/en/page/">
<link rel="alternate" hreflang="fr" href="https://example.com/fr/page/">
<link rel="alternate" hreflang="x-default" href="https://example.com/page/">
\`\`\`

## Schema Markup (Structured Data)

While not a traditional meta tag, schema.org structured data in JSON-LD format helps search engines understand your content and can unlock rich results — star ratings, FAQ dropdowns, event dates, and more appearing directly in search results.

\`\`\`html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Tool",
  "name": "JSON Formatter",
  "description": "Free online JSON formatter and validator",
  "url": "https://example.com/tools/json-formatter"
}
</script>
\`\`\`

## Auditing Your Meta Tags

Use browser developer tools (View Source or Elements panel) to inspect a page's meta tags. Google Search Console shows how your pages appear in search results and highlights missing or duplicate title and description issues. Tools like Screaming Frog can crawl your entire site and audit all meta tags in bulk.

## Conclusion

Meta tags are one of the highest-leverage technical SEO investments you can make. A well-crafted title tag and description improve click-through rates. Proper OG and Twitter Card tags ensure your content looks great when shared. Canonical tags prevent duplicate content penalties. Use ToolHub's Meta Tag Generator to create a complete set of meta tags for any page instantly.`,
  },
  {
    id: 'slug-generator-guide',
    title: 'URL Slugs: The Complete Guide for SEO-Friendly URLs',
    description: 'Learn what URL slugs are, why they matter for SEO, and how to create clean, optimised slugs for blog posts, products, and pages.',
    relatedTool: 'slug-generator',
    category: 'SEO',
    color: 'teal',
    readTime: 7,
    publishDate: '2024-11-22',
    tags: ['slug', 'url', 'seo', 'permalinks'],
    relatedBlogs: ['meta-tags-complete-guide', 'url-encoding-explained', 'keyword-density-seo'],
    content: `A URL slug is the human-readable part of a web address that identifies a specific page. In the URL https://example.com/blog/how-to-make-coffee, the slug is how-to-make-coffee. It is short, descriptive, and instantly tells both users and search engines what the page is about. Creating clean, optimised slugs is one of the simplest and highest-impact SEO practices available to web publishers.

## What is a URL Slug?

The term "slug" comes from newspaper publishing, where it referred to a short label used to identify a story during production. In web development, it has the same purpose — it is a concise identifier for a page, used in the URL.

Slugs are the part of the URL path that follows the domain and any directory structure. They are usually derived from the page title or headline, with spaces replaced by hyphens and special characters removed or converted.

Examples of good slugs:
- /blog/seo-guide-beginners (from "SEO Guide for Beginners")
- /products/wireless-noise-cancelling-headphones
- /tools/json-formatter

## Why Slugs Matter for SEO

Search engines use URL structure as one of many signals when understanding and ranking pages. A descriptive slug that contains the target keyword provides a clear, unambiguous signal about the page's topic. When someone searches for "JSON formatter online", a URL containing /json-formatter is a stronger signal than /tools/tool_id=47_v2.

Additionally, when other websites link to your page, the anchor text visible in the URL itself contributes to your page's relevance signals. A clean slug is also easier to remember, share, and type — improving organic sharing and direct traffic.

Google's own documentation recommends using words in URLs and keeping them simple. URLs like /p?id=278 provide no information about the page's content.

## Anatomy of a Good Slug

A well-crafted slug has these characteristics:

**Uses only lowercase letters**: Servers may treat My-Page and my-page as different URLs, creating duplicate content issues. Always use lowercase.

**Uses hyphens as word separators**: Google treats hyphens as word separators, just like spaces. Underscores are treated as joining characters — word_count is seen as one word, while word-count is seen as two. Use hyphens.

**Is concise**: The best slugs are short and direct. Remove stop words (a, an, the, of, for, in, on) unless they add meaning. "how-to-format-json" is better than "how-to-properly-format-and-beautify-json-data-online".

**Contains the primary keyword**: Include your main target keyword in the slug if possible, near the beginning.

**Avoids special characters and symbols**: Characters like &, %, ?, and # either need to be percent-encoded or can break URL parsing. Stick to alphanumeric characters and hyphens.

**Does not include dates** (usually): Including the year in a slug like /2024/seo-guide can make the content feel dated and may hurt long-term traffic to evergreen content. Use dates only for news articles where recency is a feature.

## How to Convert Titles to Slugs

The process of generating a slug from a title involves several steps:

1. Convert to lowercase: "The Best JSON Tools" becomes "the best json tools"
2. Remove or replace special characters: "C++ Guide" becomes "c-guide"
3. Replace spaces with hyphens: "the best json tools" becomes "the-best-json-tools"
4. Remove stop words (optional): becomes "best-json-tools"
5. Remove consecutive hyphens: "the--json--tools" becomes "the-json-tools"
6. Trim leading/trailing hyphens

ToolHub's Slug Generator handles all of these steps automatically. Paste any title and get an SEO-ready slug instantly.

## Slug Length Guidelines

There is no absolute maximum slug length, but shorter is generally better for readability and sharing. Aim for:
- Ideal: 3-5 words, 20-50 characters
- Acceptable: up to 6-7 words
- Avoid: slugs over 75 characters — they get truncated in search results and look unwieldy

Google does not penalise longer URLs, but shorter URLs tend to get more clicks because they look cleaner in search results and are easier to remember.

## Managing Slug Changes

One of the most common SEO mistakes is changing a slug after a page is indexed. If you change /blog/old-slug to /blog/new-slug, any links pointing to the old URL will break, losing their link equity. If you must change a slug:

1. Set up a 301 permanent redirect from the old URL to the new one
2. Update any internal links that pointed to the old URL
3. Update your sitemap
4. Use Google Search Console to monitor for any 404 errors

In WordPress, Shopify, and most CMS platforms, you can set up redirects directly in the admin panel or via redirect plugins.

## Common Slug Mistakes to Avoid

**Keyword stuffing**: A slug like best-free-online-json-formatter-tool-converter-beautifier looks spammy to both users and search engines.

**Including file extensions**: Modern CMS platforms serve pages without .html extensions. Avoid slugs ending in .php or .html unless technically required.

**Using query parameters as content identifiers**: /page?id=42 is not a slug — it is a query parameter. All unique pages should have path-based slugs.

**Inconsistent conventions**: Using underscores on some pages and hyphens on others, or mixing uppercase and lowercase, creates an unprofessional impression and can cause canonical issues.

## Slugs for Different Content Types

**Blog posts**: Keyword-focused, evergreen slugs. Avoid dates unless it is a news-style site.

**Product pages**: Include key product attributes. /products/mens-running-shoes-size-12 is better than /products/item-9847.

**Category pages**: Short and broad. /tools/developer-tools or /tools/text.

**Location pages**: Include city or region. /services/web-design-london.

## International and Multilingual Slugs

For multilingual sites, create separate slug conventions per language. Do not translate slugs automatically — research keywords in the target language independently. A direct translation may not be the highest-volume search term in that language.

Use language-specific subdirectories (/fr/, /de/) or subdomains combined with properly localised slugs. Ensure hreflang tags connect the language variants correctly.

## Conclusion

A good URL slug is one of the simplest, most impactful SEO improvements you can make. It costs nothing, takes seconds to set up, and pays dividends in search visibility and user trust for years. Use ToolHub's Slug Generator to create perfect slugs for any title — just paste your headline and copy the result.`,
  },
  {
    id: 'what-is-uuid',
    title: 'What is a UUID? UUIDs Explained for Developers',
    description: 'A complete guide to UUIDs (Universally Unique Identifiers) — the different versions, when to use them, and how they compare to other ID strategies.',
    relatedTool: 'uuid-generator',
    category: 'Developer',
    color: 'purple',
    readTime: 7,
    publishDate: '2024-11-25',
    tags: ['uuid', 'identifier', 'developer', 'database'],
    relatedBlogs: ['what-is-json-formatter', 'password-security-guide', 'md5-sha256-difference'],
    content: `A UUID (Universally Unique Identifier) is a 128-bit identifier, typically displayed as a 32-character hexadecimal string in the format xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx. You have almost certainly encountered UUIDs in APIs, databases, file systems, and URLs. Understanding what they are, why they exist, and when to use them is essential knowledge for any software developer.

## What Does a UUID Look Like?

A standard UUID looks like this: 550e8400-e29b-41d4-a716-446655440000

It consists of five groups of hexadecimal digits, separated by hyphens: 8-4-4-4-12 characters. This is specified in RFC 4122, the UUID standard. The same UUID in its compact form without hyphens would be 550e8400e29b41d4a716446655440000.

The total number of possible UUIDs in version 4 (random) is 2^122, or approximately 5.3x10^36. To put that in perspective: if you generated one billion UUIDs per second for the entire age of the universe, you would still have used only a tiny fraction of the available space. Collisions are theoretically possible but practically impossible.

## UUID Versions Explained

The UUID standard defines five versions, each generated differently:

**Version 1 (Time-based)**: Generated using the current timestamp and the MAC address of the machine generating it. The timestamp component means UUIDs are chronologically sortable. The downside is that including the MAC address can be a privacy concern.

**Version 2 (DCE Security)**: Similar to v1 but includes POSIX UID/GID information. Rarely used in modern applications.

**Version 3 (Name-based, MD5)**: Generated by hashing a namespace UUID and a name using MD5. Produces the same UUID for the same name in the same namespace — useful for creating deterministic IDs from known inputs.

**Version 4 (Random)**: Generated using cryptographically random numbers. By far the most commonly used version. When people say "UUID", they almost always mean UUIDv4.

**Version 5 (Name-based, SHA-1)**: Like v3 but uses SHA-1 instead of MD5. Preferred over v3 for new applications.

## Why Use UUIDs Instead of Sequential IDs?

The traditional approach to database IDs is auto-incrementing integers (1, 2, 3...). This is simple and efficient, but has significant limitations:

**Enumeration attacks**: Sequential IDs expose your data structure. If a user can access /api/orders/1001, they may try /api/orders/1002 to access someone else's order. UUIDs do not have this problem.

**Distributed systems**: In a system with multiple databases or microservices, sequential IDs conflict — two services might both generate ID 5000. UUIDs can be generated independently without coordination.

**Data merging**: When migrating or merging databases, sequential integer IDs from two sources will conflict. UUID-identified records can be merged without any ID changes.

**No information leakage**: Sequential IDs reveal how many records exist and roughly when a record was created. UUID v4 reveals nothing.

## Downsides of UUIDs

**Storage size**: A UUID takes 16 bytes as binary or 36 characters as text. An integer takes 4-8 bytes. This difference matters at scale — a table with 100 million UUIDs will have significantly larger indexes than one with integers.

**Readability**: user_id=7 is easier to discuss in a meeting than user_id=550e8400-e29b-41d4-a716-446655440000.

**Index performance**: Random UUIDs (v4) cause index fragmentation in B-tree indexes because new values are inserted randomly rather than at the end. This degrades insert performance at very high scale.

**Not human-memorable**: You cannot remember or type a UUID. This matters for customer-facing IDs like order numbers.

## ULIDs: A Modern Alternative

ULID (Universally Unique Lexicographically Sortable Identifier) is a newer alternative that addresses UUID's index performance problem. A ULID encodes the current timestamp in the first 48 bits and randomness in the remaining 80 bits, making it sortable by creation time while still being highly unique. ULIDs are encoded in Crockford's Base32, producing 26-character strings like 01ARZ3NDEKTSV4RRFFQ69G5FAV.

## When to Use UUIDs

Use UUIDs for:
- Public-facing IDs in APIs: Never expose sequential integers in external APIs
- Distributed or multi-tenant systems: Where IDs are generated across multiple services
- User IDs, session tokens, and device IDs: Where privacy and unpredictability matter
- Files and uploads: UUID-named files avoid conflicts in storage systems

Consider alternatives for:
- High-frequency insert tables where index performance is critical (consider ULID or sequential UUIDs)
- Customer-facing order numbers that users need to reference (use short, human-friendly codes instead)
- Internal join tables with very high row counts (integers may perform better)

## Generating UUIDs in Code

\`\`\`javascript
// Node.js (built-in since v15.6)
const { randomUUID } = require('crypto')
const id = randomUUID()

// Browser
const id = crypto.randomUUID()

// Python
import uuid
id = str(uuid.uuid4())
\`\`\`

## UUID Namespaces for Deterministic IDs

UUID versions 3 and 5 accept a namespace and a name, always producing the same UUID for the same combination. Predefined namespaces include DNS, URL, OID, and X.500. This is useful for generating stable IDs for known entities — for example, always generating the same UUID for a given username or email address.

\`\`\`python
import uuid
# Always produces the same UUID for this email
user_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, 'alice@example.com'))
\`\`\`

## Conclusion

UUIDs are a fundamental tool for building robust, secure, and scalable systems. Understanding the differences between UUID versions and knowing when UUIDs are the right choice will help you make better architectural decisions. ToolHub's UUID Generator creates cryptographically random v4 UUIDs instantly — use it whenever you need a unique identifier for testing, configuration, or development.`,
  },
  {
    id: 'keyword-density-seo',
    title: 'Keyword Density in SEO: The Real Story in 2024',
    description: 'Everything you need to know about keyword density — what it is, whether it still matters for SEO, and how to write naturally optimised content.',
    relatedTool: 'keyword-density-checker',
    category: 'SEO',
    color: 'amber',
    readTime: 7,
    publishDate: '2024-11-28',
    tags: ['keyword density', 'seo', 'content', 'on-page seo'],
    relatedBlogs: ['meta-tags-complete-guide', 'slug-generator-guide', 'open-graph-guide'],
    content: `Keyword density is one of the oldest concepts in SEO — and one of the most misunderstood. In the early days of search engines, stuffing keywords into a page was a reliable way to rank for those terms. Today, the landscape is completely different. Here is what keyword density actually means in 2024, how modern search engines evaluate keyword usage, and how to write content that ranks without falling into outdated traps.

## What is Keyword Density?

Keyword density is the percentage of times a target keyword appears relative to the total word count of a page. The formula is:

Keyword Density = (Number of keyword appearances divided by Total words) multiplied by 100

For example, if a 1,000-word article contains the phrase "JSON formatter" 10 times, the keyword density is 1%. If it appears 20 times, the density is 2%.

The idea behind keyword density as an SEO metric was straightforward: if a page mentions "running shoes" frequently, it is probably about running shoes. Early search algorithms used this as a primary relevance signal.

## Does Keyword Density Still Matter?

The short answer: keyword density as a specific percentage target is largely obsolete, but keyword usage still matters in more nuanced ways.

Google's algorithms have evolved dramatically. Modern systems use natural language processing (NLP), semantic analysis, and contextual understanding to evaluate relevance. Google understands synonyms, related concepts, and the intent behind search queries. A page about "running shoes" that never mentions "athletic footwear" or "sneakers" might be less comprehensively relevant than one that naturally uses related terminology.

There is no magic keyword density percentage. Studies that once suggested "2-3% is optimal" were based on correlation data from simpler algorithm eras. Google has explicitly stated it does not have a keyword density requirement.

What does matter:
- Does the keyword appear in key places (title, H1, first paragraph)?
- Is the keyword used naturally throughout the content?
- Are related terms and semantic concepts also present?
- Is the content genuinely helpful and comprehensive on the topic?

## The Problem with Keyword Stuffing

Keyword stuffing — the practice of forcing a keyword into content as many times as possible — actively harms rankings today. Google's spam policies specifically target keyword stuffing, and pages that engage in it can receive manual penalties or algorithmic demotion.

Keyword-stuffed content is also terrible for users. Reading "Our JSON formatter is the best JSON formatter for JSON formatting. Use our JSON formatter to format JSON..." is painful and builds no trust with readers. High bounce rates from users who immediately leave signal to Google that the page is low quality.

## Where Keywords Actually Matter

Rather than optimising for a density percentage, focus on keyword placement in high-impact locations:

**Title tag**: Your primary keyword should appear in the title. This is the most important placement for SEO. Keep the title natural — a forced keyword at the expense of readability is counterproductive.

**H1 heading**: The main heading of your page should contain or closely relate to your target keyword.

**First paragraph**: Mentioning your keyword early signals strong relevance. Aim to include it naturally within the first 100 words.

**Subheadings (H2, H3)**: Use variations of your keyword in subheadings to signal topical breadth. Exact match keywords in every heading look unnatural.

**Image alt text**: Describe images accurately. If an image shows a JSON formatter tool, appropriate alt text includes the relevant terms.

**URL slug**: Include your primary keyword in the URL slug.

**Meta description**: While not a ranking factor, including keywords in the meta description helps users identify relevance and can improve click-through rates.

## Semantic SEO: The Modern Approach

Rather than counting keyword occurrences, focus on semantic richness. Search engines build topic models that associate concepts together. A comprehensive article about JSON will naturally contain terms like: formatter, validator, parser, stringify, parse, API, REST, developer tools, debugging, indentation, schema.

An article that only ever mentions "JSON formatter" without any of these related concepts might rank for that exact phrase but miss broader topic authority. An article that comprehensively covers the topic will naturally include many of these terms and rank for a wider range of related queries.

## Practical Content Writing Guidelines

Write for humans first. If your content reads naturally and provides genuine value, keyword usage will generally take care of itself. Here is a practical framework:

**Research phase**: Identify your primary keyword, 2-3 secondary keywords, and 5-10 related terms (also called semantically related terms).

**Outline phase**: Structure your content around the questions and subtopics users actually want to know about. Use keyword tools or SERP analysis to identify common questions.

**Writing phase**: Write naturally. Include your primary keyword where it fits naturally — do not force it.

**Review phase**: Read back the content. If any keyword use sounds awkward or repetitive, rewrite those sections. Use synonyms and related terms freely.

**Technical phase**: Verify your title tag, H1, and first paragraph include the primary keyword. Check that your meta description is compelling.

## Content Length and Quality

Modern SEO rewards comprehensive, genuinely useful content. A 200-word page that covers a topic superficially will struggle to rank against a 1,500-word page that thoroughly addresses the topic, including common questions, use cases, and edge cases.

This does not mean padding content with fluff to hit a word count. Every paragraph should add value. If you find yourself repeating points or adding sections that do not help the reader, cut them. Quality beats quantity — but comprehensive quality beats both.

## Using a Keyword Density Checker

A keyword density checker is useful not as a tool to hit a target percentage, but as a diagnostic tool to catch keyword stuffing before publishing. If your checker shows a particular phrase at 4-5% density, that is a red flag — you have probably overused it. Review the content and replace some occurrences with synonyms or related terms.

It is also useful for checking that your primary keyword actually appears meaningfully in the content, that no unintended phrases are dominating the text, and that stop words and filler phrases are not inflating word count without adding value.

## Conclusion

Keyword density as a precise metric is an outdated concept, but intelligent keyword usage remains fundamental to SEO. Write comprehensive, helpful content, include your keyword in high-impact locations, use semantically related terms naturally, and never sacrifice readability for keyword counts. Use ToolHub's Keyword Density Checker to audit your content and catch issues before publishing.`,
  },

  {
    id: 'csv-json-conversion',
    title: 'CSV to JSON and JSON to CSV: The Developer\'s Complete Guide',
    description: 'Learn how to convert between CSV and JSON formats — the differences, conversion techniques, edge cases, and when to use each format.',
    relatedTool: 'csv-to-json',
    category: 'Developer',
    color: 'emerald',
    readTime: 8,
    publishDate: '2024-12-01',
    tags: ['csv', 'json', 'data conversion', 'developer'],
    relatedBlogs: ['what-is-json-formatter', 'how-to-format-json', 'sql-formatter-guide'],
    content: `CSV and JSON are the two most common data interchange formats in software development. CSV is ubiquitous in spreadsheets and data analysis; JSON is the native language of web APIs. Knowing how to convert between them quickly and accurately is a practical skill every developer needs. This guide covers the differences between the formats, conversion strategies, edge cases, and when to use each.

## Understanding CSV

CSV (Comma-Separated Values) is a plain text format for tabular data. Each line in a CSV file represents one row, and values within each row are separated by commas (or sometimes tabs or semicolons). The first row typically contains column headers.

A simple CSV file:

name,age,email,city
Alice,30,alice@example.com,London
Bob,25,bob@example.com,Paris
Charlie,35,charlie@example.com,New York

CSV is simple, universally supported, and opens directly in Excel and Google Sheets. However, it can only represent flat, two-dimensional tabular data. No nesting, no arrays within cells, no type information (all values are strings unless a consumer interprets them).

## Understanding JSON for Data

JSON can represent any data structure: flat tables, nested objects, arrays of objects, mixed types, and hierarchical data. An equivalent JSON representation of the CSV above looks like this:

\`\`\`json
[
  {"name": "Alice", "age": 30, "email": "alice@example.com", "city": "London"},
  {"name": "Bob", "age": 25, "email": "bob@example.com", "city": "Paris"},
  {"name": "Charlie", "age": 35, "email": "charlie@example.com", "city": "New York"}
]
\`\`\`

JSON preserves types (note that age is a number, not a string), supports Unicode naturally, and can represent nested data. It is the format APIs speak.

## When to Use CSV vs. JSON

Use CSV when:
- Data will be opened in Excel or Google Sheets
- Data is purely tabular (rows and columns, no nesting)
- You are importing/exporting from databases or data analysis tools
- File size is critical and data is highly repetitive
- Non-technical stakeholders need to view or edit the data

Use JSON when:
- Data has nested structures or arrays within records
- Data will be consumed by a web API or JavaScript application
- Types need to be preserved (numbers, booleans, null vs. empty string)
- Data has variable fields across records
- Data will be stored in a document database like MongoDB

## CSV to JSON Conversion

The basic algorithm for CSV to JSON conversion:
1. Parse the header row to get field names
2. For each subsequent row, create a JSON object with header names as keys and row values as values
3. Return an array of these objects

Edge cases to handle:

**Quoted fields**: CSV values containing commas or newlines must be enclosed in double quotes. "Smith, John" is a single value. Naive CSV parsers that just split on commas will break this.

**Escaped quotes within values**: A double quote within a quoted field is represented as two double quotes.

**Type inference**: Should "30" in a CSV become the number 30 or the string "30" in JSON? Most converters offer options for this. Enabling type inference converts obvious numbers, booleans, and empty strings to null.

**Different delimiters**: Some CSV files use semicolons (common in European locales where commas are decimal separators) or tabs (TSV files). A good converter auto-detects the delimiter.

**Encoding issues**: CSV files from Excel may be in Windows-1252 encoding rather than UTF-8, causing issues with special characters. Always convert to UTF-8 before processing.

## JSON to CSV Conversion

Going from JSON to CSV is straightforward for flat arrays of objects but gets complex with nested data.

For a flat array of objects, the algorithm is:
1. Extract all unique keys across all objects as column headers
2. For each object, write values in column order, using empty string for missing keys
3. Properly quote any values containing commas or newlines

**Handling nested objects**: A JSON object like {"user": {"name": "Alice", "age": 30}} cannot be directly mapped to CSV columns. Options include: flattening to create columns user.name and user.age using dot notation, serialising nested objects to JSON strings within the CSV cell, or skipping nested data entirely.

**Handling arrays**: A JSON array within a record similarly has no direct CSV equivalent. Common approaches include joining with a separator, expanding to multiple rows, or skipping.

## Python CSV-JSON Conversion

\`\`\`python
import csv, json

# CSV to JSON
with open('data.csv', 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    data = list(reader)
with open('data.json', 'w') as f:
    json.dump(data, f, indent=2)

# JSON to CSV
with open('data.json', 'r') as f:
    data = json.load(f)
with open('output.csv', 'w', newline='', encoding='utf-8') as f:
    if data:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)
\`\`\`

## JavaScript CSV-JSON Conversion

For robust CSV parsing in Node.js, use the papaparse library, which handles all the edge cases mentioned above. For simple cases without embedded commas or newlines in values, a basic split approach works.

For production use, always reach for a well-tested CSV library rather than writing your own parser. The edge cases around quoted fields, escaped characters, and different line endings make CSV deceptively complex to parse correctly.

## Large File Considerations

For large CSV files (millions of rows), loading the entire file into memory and converting at once is impractical. Use streaming approaches: Node.js streams with csv-parse, Python's csv.reader as a generator, or dedicated data tools like DuckDB or Apache Arrow.

When processing large files, also consider chunking the output into multiple JSON files or using JSON Lines format (one JSON object per line) instead of a single large JSON array. JSON Lines is much more memory-efficient to process and supports parallel processing.

## Data Type Handling

One of the trickiest aspects of CSV-to-JSON conversion is deciding how to handle data types. CSV has no native type system — everything is a string. Your conversion tool needs a strategy:

**No type inference**: All values become strings. Safe but loses type information.

**Automatic type inference**: Numbers, booleans, and null are detected and converted. Convenient but can produce unexpected results (e.g., "001234" becoming the number 1234, losing the leading zeros).

**Schema-guided conversion**: You define the expected types for each column. Most reliable but requires upfront configuration.

For production pipelines, schema-guided conversion is strongly recommended to avoid surprising type coercion.

## Conclusion

Understanding the structural differences between CSV and JSON — and the edge cases in conversion — will save you significant debugging time. For quick conversions, ToolHub's CSV to JSON and JSON to CSV tools handle all the common edge cases in your browser without uploading your data to any server.`,
  },
  {
    id: 'open-graph-guide',
    title: 'Open Graph Protocol: The Complete Implementation Guide',
    description: 'A thorough guide to implementing Open Graph tags for perfect social media link previews on Facebook, LinkedIn, Twitter, and Slack.',
    relatedTool: 'open-graph-generator',
    category: 'SEO',
    color: 'pink',
    readTime: 8,
    publishDate: '2024-12-05',
    tags: ['open graph', 'social media', 'seo', 'html'],
    relatedBlogs: ['meta-tags-complete-guide', 'robots-txt-guide', 'slug-generator-guide'],
    content: `When someone shares your web page on Facebook, LinkedIn, Slack, or any major social platform, what they see is determined almost entirely by your Open Graph meta tags. A compelling, well-formatted link preview can double the click-through rate of a shared link. A missing or broken preview leaves a poor impression and loses potential traffic. This guide covers everything you need to implement Open Graph correctly.

## What is Open Graph?

The Open Graph protocol was introduced by Facebook in 2010 to standardise how web pages present themselves when shared on social platforms. It uses a set of meta tags with the og: prefix that provide explicit instructions about a page's title, description, image, and type.

Before Open Graph, social platforms had to guess what content to display when a URL was shared — crawling the page and picking the first image or the first paragraph of text. Results were inconsistent and often wrong. Open Graph solved this by giving publishers explicit control.

Today, Open Graph tags are used by: Facebook, Instagram, LinkedIn, Pinterest, Slack, Discord, Microsoft Teams, iMessage link previews, WhatsApp, and many other messaging and social platforms.

## Core Open Graph Tags

There are four essential OG tags that every page should have:

\`\`\`html
<meta property="og:title" content="Your Page Title">
<meta property="og:description" content="A compelling description of your page.">
<meta property="og:image" content="https://example.com/images/og-image.jpg">
<meta property="og:url" content="https://example.com/current-page-url">
\`\`\`

**og:title**: The title of your content as it should appear in the preview card. This can differ from your HTML title tag — the OG title is specifically for social sharing. Recommended length: 60-90 characters.

**og:description**: A 1-2 sentence description of the page content. This appears below the title in most preview cards. Aim for 100-200 characters. Write it as compelling ad copy — this is what convinces people to click.

**og:image**: The URL of the image to show in the preview. This is the most impactful element — a strong, relevant image dramatically increases engagement. Must be an absolute URL starting with https://.

**og:url**: The canonical URL of the page. This ensures that even if the link was shared with tracking parameters, the preview shows the canonical address.

## Open Graph Image Requirements

The image is the most important element of a link preview. Requirements and recommendations:

- Minimum size: 600x315 pixels (1.91:1 aspect ratio)
- Recommended size: 1200x630 pixels for high-resolution displays
- Maximum file size: Facebook allows up to 8MB; aim for under 1MB for fast loading
- Formats: JPEG and PNG are universally supported; avoid WebP as some platforms do not support it
- Secure URL: Must be served over HTTPS

Design guidelines:
- Keep important content (logos, text) away from edges as some platforms crop to square
- Use high contrast for any text in the image
- Include your brand or site name
- Avoid overly busy or cluttered images
- Test your images on multiple platforms — preview sizes vary

Create a consistent template for OG images across your site. Tools like Figma, Canva, or Cloudinary's automatic transformation API can generate OG images at scale.

## Additional Useful Tags

Beyond the four core tags, these are commonly useful:

\`\`\`html
<meta property="og:type" content="website">
<!-- Options: website, article, book, profile, video.movie, music.song -->

<meta property="og:site_name" content="ToolHub">
<!-- The name of your website, shown alongside the title -->

<meta property="og:locale" content="en_US">
<!-- Language and region of your content -->

<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<!-- Explicitly declaring dimensions helps platforms display images faster -->

<meta property="og:image:alt" content="Description of the image">
<!-- Alt text for accessibility -->
\`\`\`

## Open Graph for Articles

For blog posts and news articles, use the article type and its associated tags:

\`\`\`html
<meta property="og:type" content="article">
<meta property="article:published_time" content="2024-12-05T09:00:00Z">
<meta property="article:modified_time" content="2024-12-05T09:00:00Z">
<meta property="article:author" content="https://example.com/authors/jane-doe">
<meta property="article:section" content="Technology">
<meta property="article:tag" content="SEO">
\`\`\`

Facebook and LinkedIn use this information to show publication dates and categorise article content appropriately.

## Twitter Card Tags

Twitter (now X) supports Open Graph but also has its own card tags that provide additional control. Twitter will fall back to OG tags if Twitter-specific tags are absent.

\`\`\`html
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Your Page Title">
<meta name="twitter:description" content="Description for Twitter sharing.">
<meta name="twitter:image" content="https://example.com/twitter-image.jpg">
<meta name="twitter:image:alt" content="Image description">
<meta name="twitter:site" content="@yourhandle">
<meta name="twitter:creator" content="@authorhandle">
\`\`\`

Use summary_large_image for most content pages — it shows a full-width image above the title. Use summary for brand awareness cards where you want to show a small square image alongside text.

## Testing Your Open Graph Tags

Several official tools let you preview and debug OG tags:

**Facebook Sharing Debugger** (developers.facebook.com/tools/debug/): Fetches your page as Facebook sees it and shows the preview card. Also lets you clear Facebook's cache if you updated tags but the old preview still shows.

**LinkedIn Post Inspector** (linkedin.com/post-inspector/): Similar tool for LinkedIn previews.

**Twitter Card Validator**: Accessible in Twitter's developer portal.

Always test after making changes to OG tags. Caching is aggressive — platforms cache previews for hours or days, so use the debugger tools to force a re-crawl.

## Dynamic OG Tags in Next.js and React

In modern React frameworks, OG tags are typically set programmatically. In Next.js 13 and later:

\`\`\`typescript
export async function generateMetadata({ params }) {
  const post = await getPost(params.slug)
  return {
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: [{ url: post.ogImage, width: 1200, height: 630 }],
      type: 'article',
      publishedTime: post.publishedAt,
    },
  }
}
\`\`\`

## Generating OG Images Automatically

For sites with many pages (blogs, e-commerce), manually creating OG images for every page is impractical. Options for automated OG image generation include Vercel OG Image Generation (using @vercel/og), Cloudinary's image transformation API with URL parameters, Puppeteer or Playwright to screenshot a rendered HTML template, and imgix with text overlay capabilities.

Automated OG images typically use a consistent template with the page title, site branding, and an optional background image, generated on-demand.

## Conclusion

Open Graph tags are one of the highest-leverage, lowest-effort SEO and marketing improvements available. A 30-minute investment in creating a strong OG image template and adding proper tags to your pages can significantly improve engagement every time your content is shared. Use ToolHub's Open Graph Generator to create all the necessary tags for any page in seconds.`,
  },
  {
    id: 'robots-txt-guide',
    title: 'Robots.txt: The Complete Guide for SEO and Web Developers',
    description: 'A complete guide to robots.txt — how it works, how to write it correctly, common mistakes, and how to use it strategically for SEO.',
    relatedTool: 'robots-txt-generator',
    category: 'SEO',
    color: 'coral',
    readTime: 8,
    publishDate: '2024-12-08',
    tags: ['robots.txt', 'seo', 'crawling', 'technical seo'],
    relatedBlogs: ['meta-tags-complete-guide', 'open-graph-guide', 'slug-generator-guide'],
    content: `The robots.txt file is one of the most misunderstood files in web development. It sits at the root of your domain, often barely 10 lines long, but it tells search engine crawlers how to navigate your site. Used correctly, it helps search engines focus their crawl budget on your most important pages. Misused, it can accidentally block your entire site from Google. This guide covers everything you need to know.

## What is Robots.txt?

Robots.txt is a plain text file placed at the root of a website (for example, https://example.com/robots.txt) that follows the Robots Exclusion Protocol. It contains instructions for web crawlers — primarily search engine bots — about which pages or sections they are allowed to crawl and index.

When a well-behaved crawler visits a website, it first checks robots.txt before crawling any other page. If the file instructs the crawler to avoid certain pages or directories, a compliant crawler will honour those instructions.

Important: robots.txt is a courtesy protocol, not a security mechanism. Malicious scrapers and bots will ignore it entirely. Never use robots.txt to protect sensitive information — use server-side authentication and access controls for that.

## Basic Robots.txt Syntax

A robots.txt file consists of one or more records, each beginning with a User-agent directive and followed by Allow and/or Disallow directives.

\`\`\`
User-agent: *
Disallow: /admin/
Disallow: /private/
Allow: /public/

Sitemap: https://example.com/sitemap.xml
\`\`\`

**User-agent**: Specifies which crawler the following rules apply to. The asterisk (*) means all crawlers. You can target specific crawlers by name (e.g., Googlebot, Bingbot, GPTBot).

**Disallow**: Specifies paths the crawler should not access. An empty Disallow value means "allow everything" (no restrictions).

**Allow**: Explicitly allows a path, even within a disallowed directory. Useful for allowing specific files within a blocked directory.

**Sitemap**: Points crawlers to your XML sitemap. This is best practice — always include it.

## Path Matching in Robots.txt

Rules apply to URL paths, not full URLs. Some matching behaviours:

- Disallow: /private/ blocks /private/, /private/page1, /private/data/file.html
- Disallow: / blocks the entire site (be very careful!)
- Disallow: /*.pdf$ blocks all PDF files (if the crawler supports wildcards — Googlebot does)
- Disallow: /search?* blocks all search result pages

Wildcards and end-of-string anchors are supported by Google and most major crawlers, but are not part of the original standard.

## What to Block with Robots.txt

Pages that should typically be blocked:

Admin interfaces (/admin/, /wp-admin/, /dashboard/): Even though crawling these is harmless if properly protected, there is no value in search engines indexing login pages or admin dashboards.

Search result pages (/search?q=): Search-on-search (Google indexing your internal search results) creates low-quality duplicate content.

Cart and checkout pages (/cart/, /checkout/): Not useful for search engine users. No one searches for a specific site's shopping cart.

User account areas (/account/, /my-profile/): Personalised pages that serve no purpose in search results.

Do NOT block:

CSS and JavaScript files: Googlebot needs to render your pages fully, and that requires loading CSS and JS. If Googlebot cannot access these, it cannot accurately assess your pages.

Any page you want indexed: This sounds obvious, but it is a common mistake — blocking a directory in robots.txt and then wondering why those pages are not indexed.

## The Crawl Budget Concept

Every website has a "crawl budget" — the number of pages Google will crawl in a given period. For small sites, crawl budget is rarely an issue. For large sites (millions of pages), managing crawl budget matters.

Blocking low-value pages (parameter-based duplicates, faceted navigation combinations, utility pages) with robots.txt can help Google spend more crawl budget on your high-value pages. This is especially relevant for large e-commerce and news sites.

## Robots.txt vs. Noindex

A critical distinction: robots.txt controls crawling (whether Google can fetch the page). The noindex meta tag controls indexing (whether Google will show the page in search results).

If you block a page in robots.txt, Google cannot crawl it — but if that page has inbound links, Google may still list the URL in search results with "No information available for this page." This is almost never what you want.

If you want a page to not appear in search results, use the noindex meta tag: the robots meta tag with content "noindex". Google needs to be able to crawl the page to see the noindex instruction.

In general: use noindex for pages you want to prevent from appearing in search results but still want Google to crawl. Use robots.txt to block pages you simply do not want crawled at all.

## Testing Your Robots.txt

Google Search Console provides a robots.txt Tester that lets you check whether specific URLs are allowed or blocked by your robots.txt file. This is the most reliable way to verify your rules are working as intended.

You can also simply navigate to yoursite.com/robots.txt in a browser to view the file, or use the curl command to fetch it.

## A Production-Ready Example

\`\`\`
User-agent: *
Disallow: /admin/
Disallow: /wp-admin/
Disallow: /cart/
Disallow: /checkout/
Disallow: /my-account/
Disallow: /search?*
Allow: /wp-admin/admin-ajax.php

User-agent: GPTBot
Disallow: /

Sitemap: https://example.com/sitemap.xml
\`\`\`

Note the GPTBot block — this is an AI training crawler that many site owners are blocking to prevent their content from being used for AI training without consent.

## Common Mistakes

**Disallow: / in production**: Blocks your entire site from all crawlers. Double-check before deploying. This is a surprisingly common accident, particularly when a staging site's robots.txt is accidentally copied to production.

**Blocking CSS and JS**: Prevents proper page rendering by Googlebot.

**Thinking robots.txt provides security**: It does not. Anyone can view your robots.txt and learn exactly which paths you are trying to hide.

**Not including a Sitemap reference**: Always include the Sitemap directive pointing to your XML sitemap.

**Conflicting rules**: When Allow and Disallow rules conflict, most crawlers use the most specific rule. Test your rules using the robots.txt Tester in Google Search Console.

## Conclusion

Robots.txt is simple but consequential. A few lines can direct search engine crawlers efficiently, preserve crawl budget, and prevent low-quality pages from cluttering your index. Use ToolHub's Robots.txt Generator to create a properly formatted file for your site, and always test it before publishing.`,
  },
  {
    id: 'jwt-explained',
    title: 'JWT Explained: JSON Web Tokens for Beginners and Beyond',
    description: 'A thorough explanation of JSON Web Tokens — how they work, their structure, signing algorithms, security considerations, and when to use them.',
    relatedTool: 'jwt-decoder',
    category: 'Security',
    color: 'coral',
    readTime: 9,
    publishDate: '2024-12-12',
    tags: ['jwt', 'authentication', 'security', 'web'],
    relatedBlogs: ['password-security-guide', 'what-is-base64', 'md5-sha256-difference'],
    content: `JSON Web Tokens (JWTs) are everywhere in modern web authentication. Nearly every new application, API, and cloud service uses JWTs in some form. Understanding how they work — and more importantly, how they can go wrong — is essential for any developer building secure applications. This guide covers everything from the basics to security pitfalls.

## What is a JWT?

A JWT (pronounced "jot") is a compact, URL-safe token for representing claims between two parties. In practice, JWTs are most commonly used for authentication and API authorisation. When a user logs into an application, the server issues a JWT that the client stores and sends with subsequent requests to prove identity.

A JWT looks like three Base64URL-encoded strings separated by dots:

eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInJvbGUiOiJhZG1pbiJ9.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c

This is not encrypted — it is encoded. Anyone who has the token can decode and read its contents. The security comes from the cryptographic signature, not from hiding the data.

## The Three Parts of a JWT

**Part 1: Header**

The header contains the token type and the signing algorithm:

\`\`\`json
{
  "alg": "HS256",
  "typ": "JWT"
}
\`\`\`

This is Base64URL-encoded to produce the first segment.

**Part 2: Payload (Claims)**

The payload contains the "claims" — statements about the user and additional metadata:

\`\`\`json
{
  "sub": "user_12345",
  "name": "Alice Johnson",
  "role": "admin",
  "iat": 1703155200,
  "exp": 1703241600
}
\`\`\`

Standard claim names: sub (subject — the user identifier), iss (issuer — who issued the token), aud (audience — who the token is intended for), iat (issued at — Unix timestamp of token creation), exp (expiration — Unix timestamp when the token expires).

**Part 3: Signature**

The signature verifies that the token has not been tampered with. For HMAC-SHA256 (HS256):

HMACSHA256(base64UrlEncode(header) + "." + base64UrlEncode(payload), secret)

Without knowing the secret key, it is computationally infeasible to create a valid signature. Any modification to the header or payload invalidates the signature.

## How JWT Authentication Works

1. User submits login credentials (username and password)
2. Server validates credentials against the database
3. Server creates a JWT with the user's ID, roles, and expiration time, signed with a secret key
4. Server returns the JWT to the client
5. Client stores the JWT (typically in memory or a cookie)
6. Client includes the JWT in the Authorization header of subsequent requests: Authorization: Bearer [token]
7. Server receives the request, validates the JWT signature, checks expiration, and extracts the user's identity from the payload — without querying the database

This is the key advantage of JWTs over session-based authentication: the server can verify identity entirely from the token itself, without a database lookup. This makes JWTs ideal for distributed systems and microservices where multiple servers need to verify requests.

## Signing Algorithms

**HS256 (HMAC-SHA256)**: A symmetric algorithm — the same secret key is used to sign and verify. Simple and fast, but the signing secret must be kept confidential on the server.

**RS256 (RSA-SHA256)**: An asymmetric algorithm. A private key signs the token; a public key verifies it. The public key can be distributed freely. Services can verify tokens without knowing the private signing key. This is best for multi-service architectures.

**ES256 (ECDSA)**: Like RS256 but uses elliptic curve cryptography. Produces shorter signatures and is computationally faster, while maintaining equivalent security.

## Critical Security Vulnerabilities

JWTs have a history of critical security vulnerabilities, mostly from implementation mistakes:

**The "alg:none" attack**: Early JWT libraries accepted tokens with "alg": "none" and no signature, treating them as valid. Always explicitly specify allowed algorithms in your JWT library configuration and reject none.

**HS256/RS256 confusion**: If a library accepts both symmetric and asymmetric algorithms and a server uses an RS256 public key as the HS256 secret, an attacker can sign their own tokens with the known public key. Libraries should enforce a single expected algorithm.

**Weak secrets**: HS256 tokens signed with short or common secrets can be brute-forced. Use a cryptographically random secret of at least 256 bits (32 bytes).

**Missing expiration**: Tokens without exp claims are valid forever. Always set short expiration times (15 minutes for access tokens).

**Storing JWTs in localStorage**: localStorage is accessible to JavaScript, making it vulnerable to XSS attacks. Store access tokens in memory; store refresh tokens in httpOnly cookies.

## Access Tokens vs. Refresh Tokens

Short-lived access tokens (5-15 minutes) authorise API requests. When they expire, the client uses a long-lived refresh token to get a new access token without re-authentication. Refresh tokens should be stored in httpOnly cookies, be rotated on every use, and be invalidated on logout.

This pattern gives you the stateless benefits of JWTs for API calls while maintaining the ability to revoke long-term access.

## Decoding JWTs for Debugging

Because JWT payloads are just Base64URL-encoded JSON, you can decode them to inspect their contents — useful for debugging and understanding what claims are present. Remember: decoding does not validate the signature. Anyone can decode any JWT. Signature validation, which requires the secret or public key, is what provides security.

ToolHub's JWT Decoder lets you paste a token and instantly see the decoded header and payload without sending anything to a server.

## When to Use JWTs

Good use cases: API authentication, single sign-on (SSO) across services, stateless microservices, mobile app authentication.

Better alternatives exist for: Simple single-server session management (traditional server-side sessions are easier and more revocable), storing sensitive data in tokens (remember: not encrypted), and use cases where immediate token revocation is critical (JWTs are valid until expiry unless you implement a token blocklist).

## Conclusion

JWTs are a powerful but nuanced authentication mechanism. Understanding the three-part structure, how signatures work, the difference between signing algorithms, and the critical security pitfalls is essential for implementing them safely. Use ToolHub's JWT Decoder whenever you need to inspect a token during development or debugging.`,
  },
  {
    id: 'md5-sha256-difference',
    title: 'MD5 vs SHA-256: Which Hashing Algorithm Should You Use?',
    description: 'A clear comparison of MD5 and SHA-256 hashing algorithms — how they work, key differences, and when to use each in modern applications.',
    relatedTool: 'md5-generator',
    category: 'Security',
    color: 'purple',
    readTime: 7,
    publishDate: '2024-12-15',
    tags: ['md5', 'sha256', 'hashing', 'cryptography', 'security'],
    relatedBlogs: ['password-security-guide', 'jwt-explained', 'what-is-base64'],
    content: `MD5 and SHA-256 are both cryptographic hash functions, but they serve very different purposes in modern applications. One is essentially retired for security purposes; the other remains one of the most widely used algorithms in the world. Understanding the difference — and knowing when to use neither — is fundamental security knowledge for every developer.

## What is a Hash Function?

A cryptographic hash function takes an input of any size and produces a fixed-size output (called a hash, digest, or checksum) that has several important properties:

**Deterministic**: The same input always produces the same hash.

**One-way**: Given a hash, it is computationally infeasible to determine the original input.

**Avalanche effect**: A tiny change to the input produces a completely different hash.

**Collision resistant**: It should be computationally infeasible to find two different inputs that produce the same hash.

These properties make hash functions useful for verifying data integrity, storing passwords, digital signatures, and many other security applications.

## MD5: Overview

MD5 (Message Digest 5) was designed by Ronald Rivest in 1991. It produces a 128-bit hash, typically displayed as 32 hexadecimal characters.

Example: The string "Hello, World!" produces the MD5 hash 65a8e27d8879283831b664bd8b7f0ad4.

MD5 is fast — very fast. It can hash billions of values per second on modern hardware. This speed was originally a feature but is now primarily a liability for security applications.

MD5 is cryptographically broken. Researchers demonstrated practical collision attacks against MD5 in 2004, and by 2008, attacks had advanced to the point where MD5 could no longer be trusted for any security-critical application. It is theoretically and practically possible to create two different inputs with the same MD5 hash.

## SHA-256: Overview

SHA-256 is part of the SHA-2 (Secure Hash Algorithm 2) family, published by NIST in 2001. It produces a 256-bit hash, displayed as 64 hexadecimal characters.

SHA-256 is significantly slower than MD5 but remains cryptographically secure. No practical collision attacks have been found against SHA-256. It is used in Bitcoin mining, SSL/TLS certificates, code signing, and countless security protocols.

## MD5 vs. SHA-256: Key Differences

| Property | MD5 | SHA-256 |
|----------|-----|---------|
| Output size | 128 bits (32 hex chars) | 256 bits (64 hex chars) |
| Speed | Very fast | Moderate |
| Security status | Broken | Secure |
| Collision resistance | Defeated | Strong |
| Current use | Non-security checksums | Security-critical applications |

## Where MD5 is Still Acceptable

Despite being broken for cryptographic purposes, MD5 is still appropriate for non-security checksum applications:

**File integrity checking (casual)**: Verifying that a file was not corrupted during download — not against an attacker, just against random data corruption.

**Non-security hash maps and caching**: Using MD5 as a cache key or to identify files by content where security is not a concern.

**Legacy system compatibility**: If you must interoperate with an existing system that uses MD5 and where collision attacks are not a realistic threat.

Do not use MD5 for: password storage (ever), digital signatures, certificate generation, or any security-critical application.

## Where SHA-256 Should Be Used

SHA-256 is appropriate for:

**File integrity verification**: Downloads, software packages, container images. Most modern package managers (apt, brew, pip) use SHA-256 checksums.

**Digital signatures**: SHA-256 is the standard hash used in RSA and ECDSA signature schemes.

**HMAC authentication**: HMAC-SHA256 is used in API authentication headers, JWT signatures (HS256), and message authentication codes.

**Certificate fingerprinting**: SSL/TLS certificates use SHA-256 for their fingerprint.

**Content addressing**: Git uses SHA-1 (being migrated to SHA-256) to address repository objects. Docker uses SHA-256 for image layers.

## Neither: Password Hashing

Here is the most important point in this article: neither MD5 nor SHA-256 should be used for password storage. Both are far too fast.

Password hashing requires a slow algorithm that is deliberately expensive to compute — making brute-force attacks impractical even with modern hardware. The correct algorithms for password hashing are:

**bcrypt**: Industry standard for many years. Includes a work factor that can be increased as hardware gets faster. Default work factor of 12 is currently recommended.

**scrypt**: Designed to be memory-hard as well as computationally expensive. Harder to accelerate with GPUs.

**Argon2**: The winner of the Password Hashing Competition (2015). The modern recommendation. Three variants: Argon2d (GPU resistant), Argon2i (side-channel resistant), Argon2id (balanced, recommended for most uses).

Using MD5 or SHA-256 for password storage is a critical vulnerability. Attackers with GPU clusters can crack billions of MD5-hashed passwords per second. A properly bcrypt-hashed password takes days to crack even with dedicated hardware.

## Practical Examples

\`\`\`javascript
// Node.js - SHA-256
const crypto = require('crypto')
const hash = crypto.createHash('sha256').update('input').digest('hex')

// Python
import hashlib
hash = hashlib.sha256(b'input').hexdigest()
\`\`\`

For password hashing in Node.js, use the bcrypt library:

\`\`\`javascript
const bcrypt = require('bcrypt')
const hash = await bcrypt.hash(password, 12)  // saltRounds = 12
const valid = await bcrypt.compare(inputPassword, storedHash)
\`\`\`

## SHA-3 and the Future

SHA-3 (Keccak) was published in 2015 as NIST's next-generation hash function. While SHA-256 remains secure, SHA-3 provides a different internal design that could become important if weaknesses are discovered in SHA-2. SHA-3 has not widely replaced SHA-2 in practice but is available in most cryptographic libraries.

## Conclusion

Use SHA-256 for file integrity, HMAC, digital signatures, and content addressing. Use Argon2 or bcrypt for passwords. Use MD5 only for non-security checksums where collision resistance does not matter. ToolHub provides both MD5 and SHA-256 generators for quick hash generation — useful for checksums, testing, and development.`,
  },

  {
    id: 'hex-color-guide',
    title: 'Hex Colors Explained: RGB, HSL, and Color Theory for Developers',
    description: 'A developer-focused guide to colour in CSS — hex codes, RGB, HSL, accessibility contrast ratios, and practical design tips.',
    relatedTool: 'hex-to-rgb',
    category: 'Developer',
    color: 'pink',
    readTime: 8,
    publishDate: '2024-12-18',
    tags: ['color', 'hex', 'css', 'design', 'rgb'],
    relatedBlogs: ['css-gradient-tutorial', 'meta-tags-complete-guide', 'best-free-text-tools'],
    content: `Colour is one of the most powerful tools in a developer's design toolkit, but colour systems can be confusing. Hex codes, RGB, HSL, OKLCH — what is the difference, and when should you use each? This guide demystifies colour representation in CSS and gives you practical tools for choosing, converting, and applying colours effectively.

## Hex Colour Codes

Hexadecimal colour codes are the most widely recognised colour format in web development. A hex code like #3b82f6 represents a colour in the RGB colour model using hexadecimal (base-16) notation.

The format is #RRGGBB:
- RR — red component (00 to FF, which is 0 to 255 in decimal)
- GG — green component (00 to FF)
- BB — blue component (00 to FF)

So #3b82f6 breaks down as: 3b = 59 (red), 82 = 130 (green), f6 = 246 (blue). In CSS, this is equivalent to rgb(59, 130, 246).

**Shorthand hex codes**: If each pair of digits is identical (e.g., #336699), it can be shortened to three characters (#369). The browser expands each digit to a repeated pair: 3 becomes 33, 6 becomes 66, 9 becomes 99.

**Hex with transparency**: CSS supports 8-digit hex codes where the last two characters represent opacity: #3b82f6cc (the cc = 80% opacity in hex).

## The RGB Colour Model

RGB (Red, Green, Blue) is an additive colour model — mixing all three channels at full intensity produces white; all at zero produces black. Each channel accepts values from 0 to 255.

\`\`\`css
color: rgb(59, 130, 246);           /* Solid blue */
color: rgba(59, 130, 246, 0.5);     /* 50% transparent blue */
color: rgb(59 130 246 / 50%);       /* Modern syntax */
\`\`\`

RGB is intuitive if you think in terms of how much red, green, and blue, but it is not the most human-friendly for choosing colours. Predicting that rgb(180, 100, 255) is a medium purple without a colour picker is difficult.

## The HSL Colour Model

HSL (Hue, Saturation, Lightness) is often more intuitive for developers and designers because it maps to how humans think about colour:

- **Hue**: The colour itself, expressed as a degree on the colour wheel (0/360 = red, 120 = green, 240 = blue)
- **Saturation**: How vivid the colour is (0% = grey, 100% = fully vivid)
- **Lightness**: How light or dark (0% = black, 50% = normal, 100% = white)

\`\`\`css
color: hsl(217, 91%, 60%);          /* Same blue as #3b82f6 */
color: hsl(217 91% 60% / 0.5);     /* 50% transparent */
\`\`\`

HSL is extremely useful for creating colour variations. Want a lighter version of your brand colour? Just increase the lightness. Want a muted version? Decrease saturation. This makes HSL excellent for design systems and theming.

## OKLCH: The Modern Choice

CSS Color Level 4 introduced perceptually uniform colour spaces. oklch() is the modern recommendation for design systems because it maintains consistent perceived lightness across different hues — a problem with HSL where yellow at 50% lightness appears much brighter than blue at 50% lightness.

\`\`\`css
color: oklch(65% 0.2 230);   /* Lightness, Chroma, Hue */
\`\`\`

OKLCH is supported in all modern browsers and is the format recommended by the CSS Color Level 4 specification. Tailwind CSS v4 uses OKLCH internally.

## Converting Between Colour Formats

The conversion between hex and RGB is straightforward: each pair of hex digits converts to a decimal number. Tools like ToolHub's Hex-to-RGB converter handle this instantly.

\`\`\`javascript
// Hex to RGB in JavaScript
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null
}
\`\`\`

## Colour Contrast and Accessibility

WCAG (Web Content Accessibility Guidelines) defines contrast ratio requirements to ensure text is readable for people with low vision:

**WCAG AA** (minimum requirement):
- Normal text (under 18pt): contrast ratio at least 4.5:1
- Large text (18pt+) or bold 14pt+: contrast ratio at least 3:1
- UI components and graphics: contrast ratio at least 3:1

**WCAG AAA** (enhanced):
- Normal text: contrast ratio at least 7:1
- Large text: contrast ratio at least 4.5:1

Contrast ratio is calculated from the relative luminance of two colours. White text on a #3b82f6 blue background has a contrast ratio of approximately 3.9:1 — passing AA for large text but failing for body text. Switching to a darker shade like #1d4ed8 improves contrast significantly.

Common tools for checking contrast ratios include the WebAIM Contrast Checker and browser developer tools built-in accessibility audits.

## Building a Colour Palette

For a design system, start with a primary hue and generate a scale from light to dark. Using HSL:

\`\`\`css
:root {
  --blue-50:  hsl(214, 100%, 97%);
  --blue-100: hsl(214, 95%, 93%);
  --blue-300: hsl(212, 96%, 78%);
  --blue-500: hsl(217, 91%, 60%);  /* Base colour */
  --blue-700: hsl(224, 76%, 48%);
  --blue-900: hsl(224, 64%, 33%);
}
\`\`\`

This approach (used by Tailwind CSS) gives you a consistent, accessible colour scale for any design.

## Named CSS Colours

CSS defines 147 named colours ranging from aliceblue to yellowgreen. These are convenient for quick prototyping and documentation but are not recommended for production design systems where precision matters. Named colours like cornflowerblue or mediumaquamarine have specific hex values that may not match your brand colours.

## Practical Colour Tips for Developers

**Use CSS custom properties**: Define your colour palette as CSS variables at the :root level. This enables easy theming and dark mode support.

**Avoid pure black and white**: Pure black (#000000) and pure white (#ffffff) can feel harsh. Use near-black (#0f172a) and near-white (#f8fafc) for a softer, more polished look.

**Use transparency for surfaces**: rgba or hsl with opacity creates depth. Background overlays, frosted glass effects, and hover states all benefit from transparent layers.

**Test colours in context**: A colour that looks great in isolation may clash with adjacent colours. Always evaluate colours in context with the full design.

**Consider dark mode**: Design your colour system with both light and dark modes in mind from the start. CSS custom properties make this much easier to implement.

## Colour in Data Visualisation

For charts, graphs, and data visualisations, colour choice is particularly important:
- Use distinct hues for different data series (not just different lightness values, which can be hard to distinguish)
- Ensure colours are distinguishable for colour-blind users — avoid red/green as the only distinction
- Use a consistent direction (light = lower, dark = higher) for sequential data
- Consider using patterns or shapes in addition to colour for accessibility

## Conclusion

Understanding how hex, RGB, HSL, and OKLCH represent colour gives you precise control over your UI's visual appearance. Knowing accessibility contrast requirements ensures your designs are usable by everyone. Use ToolHub's Hex-to-RGB converter to instantly translate between colour formats while building or debugging CSS.`,
  },
  {
    id: 'remove-extra-spaces-guide',
    title: 'How to Remove Extra Spaces from Text: Tools and Techniques',
    description: 'Practical guide to removing extra spaces, trailing whitespace, and invisible characters from text — for writers, developers, and data professionals.',
    relatedTool: 'remove-extra-spaces',
    category: 'Text',
    color: 'amber',
    readTime: 6,
    publishDate: '2024-12-20',
    tags: ['whitespace', 'text cleaning', 'spaces', 'formatting'],
    relatedBlogs: ['best-free-text-tools', 'what-is-json-formatter', 'slug-generator-guide'],
    content: `Extra spaces are one of the most common — and most overlooked — problems in text processing. They appear in content copied from PDFs, exported from databases, pasted from Word documents, and received from form submissions. They cause inconsistent formatting, break data processing logic, and make text look unprofessional. This guide covers why extra spaces appear, how to remove them, and how to prevent them in the first place.

## Why Extra Spaces Appear

Understanding the origin of whitespace problems helps you address them at the source:

**Copy-pasting from PDFs**: PDF extraction inserts extra spaces to represent column layouts, hyphenation, and font metrics. Text that looks fine in the PDF often contains dozens of extra spaces when pasted as plain text.

**Word processors**: Microsoft Word and Google Docs sometimes insert non-breaking spaces instead of regular spaces, especially after certain punctuation. These are invisible but cause issues in code and data processing.

**Database exports**: CSV exports from databases may include trailing spaces in string fields, especially if the original schema used CHAR (fixed-width) rather than VARCHAR types.

**HTML content**: Browsers collapse multiple spaces in HTML to a single space, masking whitespace problems in the source. When you copy from a web page, you may get clean text; when you scrape the HTML, you find multiple spaces.

**Form submissions**: Users copy-paste text into forms without noticing extra whitespace. A name field with leading or trailing spaces creates account registration issues and matching failures.

**Manual typing errors**: Double spaces after periods are a classic habit from typewriter-era typography. While single spaces are the current standard, many writers still double-space.

## Types of Whitespace Characters

Not all "spaces" are the same character. This is a frequent source of confusion:

**Regular space** (Unicode U+0020): The standard spacebar character. What you usually mean by "space".

**Non-breaking space** (U+00A0): Visually identical to a space but prevents line breaks and is not removed by standard space-removal operations. Common in copied web content.

**Thin space** (U+2009): A narrow space used in typesetting. Appears in professionally typeset content.

**Zero-width space** (U+200B): Invisible, takes up no visual width, but is present in the string. Can cause issues in data matching and URL processing.

**Tab** (U+0009): Horizontal tab character. Common in code and exported data.

A robust text cleaning tool handles all of these variants, not just standard spaces.

## Common Cleaning Operations

**Remove leading and trailing whitespace (trim)**: Remove spaces, tabs, and newlines from the beginning and end of the text. The most common operation, built into virtually every programming language.

**Collapse multiple spaces to one**: Replace two or more consecutive spaces with a single space. This handles double spacing and other repeated spaces within text.

**Remove all spaces**: Strip every space character from the text. Useful for processing numeric data or generating slugs.

**Normalise line endings**: Convert Windows-style carriage-return-linefeed line endings to Unix-style linefeed. Important when processing files across operating systems.

**Remove blank lines**: Remove empty lines or lines containing only whitespace.

**Normalise all whitespace**: Replace tabs, multiple spaces, and non-breaking spaces with single regular spaces. The most thorough cleaning option.

## How to Remove Extra Spaces in Code

\`\`\`javascript
// JavaScript
const text = '  Hello,   world!  '

// Trim leading/trailing whitespace
text.trim()                              // 'Hello,   world!'

// Collapse multiple spaces to one
text.replace(/\s+/g, ' ').trim()        // 'Hello, world!'

// Also handle non-breaking spaces (\\u00A0)
text.replace(/[\\s\\u00A0]+/g, ' ').trim()  // 'Hello, world!'

// Remove all whitespace
text.replace(/\\s/g, '')                 // 'Hello,world!'
\`\`\`

\`\`\`python
# Python
import re

text = '  Hello,   world!  '
text.strip()                            # 'Hello,   world!'
re.sub(r'\\s+', ' ', text).strip()     # 'Hello, world!'
\`\`\`

\`\`\`sql
-- SQL standard trim
SELECT TRIM(column_name) FROM table_name;
-- PostgreSQL collapse multiple spaces
SELECT REGEXP_REPLACE(column_name, '\\s+', ' ', 'g') FROM table_name;
\`\`\`

## Handling Non-Breaking Spaces

Non-breaking spaces are the trickiest whitespace character to deal with because they look exactly like regular spaces but are not matched by standard space operations.

In content management systems, particularly WordPress, non-breaking spaces often appear in the visual editor. Checking your HTML source (not the visual preview) is the only reliable way to detect them. When cleaning text programmatically, always include a step to replace non-breaking spaces with regular spaces before your main whitespace normalisation.

## Whitespace in Data Processing Pipelines

In data engineering, whitespace issues can cause silent failures that are difficult to debug. A user ID stored with a trailing space will not match a lookup for the clean version, causing a join to fail or a lookup to return nothing.

Best practices for data pipelines:
- Always trim string fields when ingesting data from external sources
- Apply normalisation consistently — if you trim one field, trim all string fields
- Use database constraints or application-level validation to prevent whitespace from being stored
- Include whitespace checks in your data quality tests

## Writer and Content Applications

For writers and content creators, extra spaces cause layout issues in publishing tools and professional documents. Common scenarios:

**Double spaces after periods**: Use find-and-replace in your word processor to normalise spacing throughout a document. Search for two spaces and replace with one.

**Copied content from PDFs**: Always paste into a plain text editor (Notepad, TextEdit in plain text mode) before pasting into your CMS or word processor. This strips most formatting including extra spaces.

**Indented paragraphs using spaces**: Use tab indentation or CSS text-indent instead of leading spaces, which format inconsistently across different contexts.

## Using ToolHub's Space Removal Tool

ToolHub's Remove Extra Spaces tool offers several cleaning options in one place: trim leading and trailing whitespace, collapse multiple consecutive spaces to one, handle non-breaking spaces, and normalise all whitespace types. Paste your text, select the desired option, and copy the cleaned output — entirely in your browser with no data leaving your device.

## Conclusion

Extra spaces are a pervasive problem in text processing, content management, and data engineering. Understanding where they come from, knowing the difference between regular and non-breaking spaces, and having reliable tools and code patterns to handle them will save you countless hours of debugging and cleanup work.`,
  },
  {
    id: 'best-free-text-tools',
    title: '12 Best Free Online Text Tools Every Writer and Developer Needs',
    description: 'A curated guide to the most useful free online text manipulation tools for writers, bloggers, developers, and SEO professionals.',
    relatedTool: 'word-counter',
    category: 'Text',
    color: 'teal',
    readTime: 8,
    publishDate: '2024-12-22',
    tags: ['text tools', 'productivity', 'writing', 'developer'],
    relatedBlogs: ['remove-extra-spaces-guide', 'slug-generator-guide', 'keyword-density-seo'],
    content: `Whether you are a blogger polishing an article, a developer cleaning data, an SEO professional auditing content, or a student editing an essay, text manipulation tools can save significant time and improve output quality. This guide covers the most genuinely useful free online text tools — what they do and when you actually need them.

## 1. Word Counter

A word counter is the simplest but most-used text tool. Paste your text and instantly see the word count, character count (with and without spaces), sentence count, paragraph count, and estimated reading time.

When you need it: Platform word limits (tweets, LinkedIn posts, Amazon product descriptions), academic paper requirements, content briefs that specify word counts, and reading time calculations for blog posts. At 250 words per minute average reading speed, a 2,000-word article takes about 8 minutes — useful information to include above the fold.

Bonus features to look for: Characters without spaces (for tweet character counting), unique word count (for vocabulary assessment), and keyword density (for SEO audits).

## 2. Text Case Converter

Instantly switch between UPPERCASE, lowercase, Title Case, Sentence case, camelCase, PascalCase, snake_case, and kebab-case.

When you need it: Developers converting variable names between formats (snake_case Python to camelCase JavaScript), writers fixing accidental CAPS LOCK activation, bloggers formatting headings consistently, and data cleaning when a field was entered in the wrong case convention.

Developer tip: Use snake_case for Python variables, camelCase for JavaScript, PascalCase for class names, and kebab-case for CSS class names and HTML IDs.

## 3. Slug Generator

Converts any title or phrase to a clean, URL-friendly slug by lowercasing, replacing spaces with hyphens, removing special characters, and optionally stripping stop words.

When you need it: Every time you create a blog post, product page, or any URL. A well-crafted slug includes your primary keyword and is concise. A long title like "The 10 Best Free Online JSON Formatting Tools for Developers in 2024" becomes a clean slug like best-free-json-formatter-tools.

## 4. Text Compare (Diff Tool)

Side-by-side comparison of two text blocks, highlighting additions, deletions, and changes — similar to git diff but for arbitrary text.

When you need it: Comparing two versions of a document without version control, reviewing changes in text-based configuration files, identifying what changed between two API responses, and checking if two strings are truly identical (useful when debugging cases where text looks the same but has invisible differences).

## 5. Duplicate Line Remover

Removes duplicate lines from a text block, with options for case-sensitive or insensitive matching and preserving original order.

When you need it: Deduplicating keyword lists before running SEO campaigns, cleaning email subscription exports, processing log files, and removing repeated items from any list. Invaluable for data cleaning tasks when you have imported data from multiple sources.

## 6. Text Sorter

Sorts lines alphabetically, numerically, by length, or in reverse, with options for case sensitivity and custom delimiters.

When you need it: Sorting keyword lists, alphabetising navigation menu items, organising code documentation, and any data cleanup task involving lists. Sorted lists are much easier to scan for completeness or duplicates.

## 7. Word Frequency Counter

Analyses text and shows how many times each word appears, ranked by frequency.

When you need it: SEO content audits (checking keyword distribution), analysing competitor content for topic coverage, detecting overused words in writing that could be replaced with synonyms, and academic text analysis. Writers use this to find "crutch words" — terms they rely on too heavily.

## 8. Keyword Density Checker

Calculates the percentage of the text occupied by a specific keyword or phrase.

When you need it: SEO copywriting — checking that your target keyword appears naturally without being stuffed (generally, 1-2% is appropriate). Also useful for checking whether a particular term dominates the text in an unintended way.

## 9. Remove Extra Spaces

Trims leading and trailing whitespace, collapses multiple consecutive spaces to one, and optionally handles non-breaking spaces.

When you need it: Cleaning text copied from PDFs, processing form submission data, preparing content for databases, and fixing formatting issues in content management systems. This is one of the most commonly needed data cleaning operations in any workflow involving text from external sources.

## 10. Line Break Remover

Removes line breaks from text to join it into a single paragraph, or normalises inconsistent line break patterns.

When you need it: PDF copy-paste frequently inserts random line breaks mid-sentence. Line Break Remover instantly fixes these. Also useful for processing text data where records were split across lines and need to be joined for further processing.

## 11. Lorem Ipsum Generator

Generates placeholder text in various lengths — words, sentences, or paragraphs — for wireframes, mockups, and design templates.

When you need it: Any time you need realistic placeholder content for a design. Lorem ipsum prevents designers from being distracted by readable text and helps clients focus on layout rather than content. Multiple paragraph options let you match the text density of your actual content.

## 12. Text Reverser

Reverses text character by character, word by word, or line by line.

When you need it: Creative writing effects, encoding simple ciphers, testing text rendering in right-to-left (RTL) contexts, and as a quick sanity check in text processing pipelines. Developers testing parsing logic frequently use text reversal to verify that character order is handled correctly.

## How to Choose the Right Tool

The right text tool depends on your primary use case:

**Writers and bloggers**: Word Counter, Text Case Converter, Slug Generator, Keyword Density Checker, Remove Extra Spaces

**Developers**: Text Compare, Duplicate Line Remover, Text Sorter, Remove Extra Spaces, Text Reverser

**SEO professionals**: Word Counter, Keyword Density Checker, Slug Generator, Duplicate Line Remover, Word Frequency Counter

**Data analysts**: Duplicate Line Remover, Text Sorter, Remove Extra Spaces, Line Break Remover

## What Makes a Good Text Tool?

The best text tools share certain qualities: they load instantly without registration, work entirely in the browser (no data sent to servers), handle edge cases correctly (special characters, Unicode, non-breaking spaces), and give immediate feedback. Performance matters too — tools that lag on large text inputs are frustrating in production workflows.

ToolHub's text tools are built with all of these principles: no signup, instant results, client-side processing, and full Unicode support throughout.

## Conclusion

The right collection of text tools can cut repetitive text manipulation tasks from minutes to seconds. Bookmark the tools that match your workflow — whether you are writing content, cleaning data, or building software, having reliable, fast text utilities at hand makes every project smoother.`,
  },
  {
    id: 'regex-for-beginners',
    title: 'Regular Expressions for Beginners: A Practical Guide',
    description: 'Learn regular expressions (regex) from scratch — core syntax, common patterns, practical examples, and how to test your patterns effectively.',
    relatedTool: 'regex-tester',
    category: 'Developer',
    color: 'purple',
    readTime: 9,
    publishDate: '2024-12-25',
    tags: ['regex', 'regular expressions', 'developer', 'pattern matching'],
    relatedBlogs: ['what-is-json-formatter', 'url-encoding-explained', 'best-free-text-tools'],
    content: `Regular expressions (regex or regexp) are one of the most powerful tools in a programmer's toolkit — and one of the most feared. A well-crafted regex can validate an email address, parse a log file, or extract data from a string in a single, compact expression. This guide builds up regex knowledge from zero, with practical patterns you can use immediately.

## What is a Regular Expression?

A regular expression is a sequence of characters that defines a search pattern. It can be used to match, search, replace, or split strings. Almost every programming language supports regex: JavaScript, Python, Java, PHP, Ruby, Go, and more — with mostly similar syntax but some variations.

In JavaScript, a regex is written between forward slashes: /pattern/flags. For example, /hello/i matches "hello", "Hello", "HELLO" and any other capitalisation.

## Core Syntax: Literals and Metacharacters

**Literals**: Most characters match themselves. The pattern /cat/ matches the string "cat" anywhere in the text.

**Metacharacters**: Special characters with regex-specific meaning. The main ones are: . ^ $ * + ? { } [ ] \\ | ( )

To match a literal metacharacter, escape it with a backslash: /\\./ matches a period; /\\$/ matches a dollar sign.

## Character Classes

A character class [...] matches any one character from the listed set:
- [abc] — matches 'a', 'b', or 'c'
- [a-z] — matches any lowercase letter
- [A-Z] — matches any uppercase letter
- [0-9] — matches any digit
- [a-zA-Z0-9] — matches any alphanumeric character
- [^abc] — matches any character NOT in the set (the ^ negates inside [])

Shorthand character classes:
- \\d — digit (equivalent to [0-9])
- \\D — non-digit
- \\w — word character (letters, digits, underscore: [a-zA-Z0-9_])
- \\W — non-word character
- \\s — whitespace (space, tab, newline)
- \\S — non-whitespace
- . — any character except newline

## Anchors

Anchors match positions, not characters:
- ^ — start of string (or start of line in multiline mode)
- $ — end of string (or end of line in multiline mode)
- \\b — word boundary
- \\B — not a word boundary

Examples:
- /^Hello/ matches strings starting with Hello
- /World$/ matches strings ending with World
- /\\bcat\\b/ matches the word "cat" but not "tomcat" or "category"

## Quantifiers

Quantifiers control how many times a pattern can repeat:
- * — 0 or more times
- + — 1 or more times
- ? — 0 or 1 time (makes the preceding element optional)
- {n} — exactly n times
- {n,} — n or more times
- {n,m} — between n and m times

Examples:
- /\\d+/ matches one or more digits
- /^\\d{5}$/ matches exactly 5-digit strings (US ZIP codes)
- /colou?r/ matches both "color" and "colour" (the u is optional)

**Greedy vs. Lazy**: By default, quantifiers are greedy — they match as much as possible. Adding ? makes them lazy (matching as little as possible):

Greedy: /\<.*\>/ on '\<b\>Bold\</b\>' matches the entire string '\<b\>Bold\</b\>'
Lazy: /\<.*?\>/ matches only '\<b\>'

## Groups and Alternation

Parentheses () create capturing groups — they group part of the pattern and capture the matched text:

\`\`\`javascript
const match = '2024-12-25'.match(/(\\d{4})-(\\d{2})-(\\d{2})/)
// match[1] = '2024', match[2] = '12', match[3] = '25'
\`\`\`

Non-capturing groups (?:...) group without capturing — useful for applying quantifiers to a group without creating a capture.

Alternation | means "or": /cat|dog/ matches either "cat" or "dog".

## Flags

Flags modify how the pattern is applied:
- i — case-insensitive (/hello/i matches 'Hello')
- g — global (find all matches, not just the first)
- m — multiline (^ and $ match line boundaries)
- s — dotAll (. matches newline characters)

## 8 Practical Regex Patterns You Can Use Today

\`\`\`
Email (simplified): /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/

Date YYYY-MM-DD: /^\\d{4}-(0[1-9]|1[012])-(0[1-9]|[12]\\d|3[01])$/

Hex colour: /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/

Strong password (min 8 chars, letter, number, symbol):
/^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$/

IPv4 address: /^(\\d{1,3}\\.){3}\\d{1,3}$/

URL: /^https?:\\/\\/[^\\s/$.?#].[^\\s]*$/

Duplicate words: /\\b(\\w+)\\s+\\1\\b/gi

Non-empty string (not just whitespace): /^(?!\\s*$).+/
\`\`\`

## Common Regex Mistakes

**Not escaping periods**: In a regex, . matches any character. To match a literal period (like in a file extension), use \\. instead.

**Greedy matching**: /\<.*\>/ intended to match one HTML tag often matches everything from the first opening bracket to the last closing bracket. Use a lazy quantifier (/\<.*?\>/) or a character class excluding the angle bracket.

**Anchoring**: A pattern without ^ and $ anchors can match anywhere in the string. /\\d+/ matches "abc123def" at the digit position. /^\\d+$/ requires the entire string to be digits.

**Not testing edge cases**: Always test your regex against empty strings, very long inputs, and strings with special characters.

## Testing and Debugging Regex

Regular expressions are notoriously tricky to get right on the first try. Always test with: strings that should match, strings that should not match, and edge cases (empty string, very long input, special characters).

ToolHub's Regex Tester lets you enter a pattern and test input in real time, with colour-coded match highlighting, capture group extraction, and error reporting. This is much faster than testing regexes in a code editor.

## When Not to Use Regex

Regex is not the right tool for every parsing problem. Do not use regex to parse HTML or XML — use a proper DOM parser. Do not use regex to validate complex formats that have dedicated parsers (dates with timezone awareness, full URL validation, emails with international domains in production). The complexity of a fully correct email regex, for example, runs to hundreds of characters.

## Conclusion

Regular expressions reward investment in learning. Start with the core syntax — character classes, quantifiers, anchors — and build from there. Use a regex tester to iterate quickly, and reference pattern libraries for common validations rather than writing complex patterns from scratch. ToolHub's Regex Tester provides instant feedback as you build and debug patterns.`,
  },
  {
    id: 'sql-formatter-guide',
    title: 'SQL Formatting Best Practices: Write Readable Queries',
    description: 'A guide to writing consistently formatted, readable SQL queries — conventions, indentation styles, naming patterns, and tools that help.',
    relatedTool: 'json-formatter',
    category: 'Developer',
    color: 'teal',
    readTime: 7,
    publishDate: '2024-12-28',
    tags: ['sql', 'formatting', 'database', 'developer'],
    relatedBlogs: ['what-is-json-formatter', 'csv-json-conversion', 'how-to-format-json'],
    content: `SQL is one of the oldest programming languages still in widespread daily use, and readable SQL is an undervalued professional skill. Poorly formatted queries are difficult to understand, hard to debug, and painful to maintain. Well-formatted SQL reads almost like plain English — exactly as its designers intended. This guide covers the conventions and practices that make SQL a pleasure to read.

## Why SQL Formatting Matters

SQL queries in production applications can span dozens of lines with multiple joins, subqueries, CTEs, and conditional logic. A query that fits neatly on screen with consistent indentation is straightforward to understand and modify. The same query written without formatting — keywords lowercase, mixed indentation, clauses on random lines — is genuinely difficult to follow, even for experienced developers.

Poor SQL formatting also makes peer review harder and increases the chance of logic errors going unnoticed. A clearly structured multi-table join is much easier to audit than an identical query written as a dense block of text.

## The Two Schools: UPPERCASE vs. lowercase Keywords

The oldest SQL formatting debate is whether to write SQL keywords in UPPERCASE or lowercase. Both are valid — SQL is not case-sensitive for keywords.

**UPPERCASE keywords** (SELECT, FROM, WHERE) is the classical convention, still dominant in enterprise environments, textbooks, and professional tools. Keywords stand out visually against table and column names.

**lowercase keywords** (select, from, where) is increasingly common in modern development, particularly in environments where SQL is embedded in code (Python, JavaScript, Go). IDEs and syntax highlighters provide visual distinction without needing uppercase.

The golden rule: pick one and be consistent throughout your project or team. Mixed case within the same query or codebase is the worst of both worlds.

## Clause-Per-Line Structure

The most impactful structural convention is writing each major SQL clause on its own line:

\`\`\`sql
-- Bad: everything on one line
SELECT u.id, u.name, o.total FROM users u JOIN orders o ON u.id = o.user_id WHERE u.active = true ORDER BY o.total DESC LIMIT 10;

-- Good: each clause on its own line
SELECT
  u.id,
  u.name,
  o.total
FROM users u
JOIN orders o ON u.id = o.user_id
WHERE u.active = true
ORDER BY o.total DESC
LIMIT 10;
\`\`\`

This structure makes it immediately clear what each clause does and makes it easy to add, remove, or comment out individual clauses during development.

## Comma Placement: Trailing vs. Leading

Another formatting debate: should commas in column lists go at the end of lines (trailing commas) or the beginning of lines (leading commas)?

Trailing commas look more natural and match conventions in other programming languages. Leading commas make it trivially easy to comment out any column without worrying about trailing commas on the preceding line. Most modern teams use trailing commas; the key is consistency.

## Common Table Expressions (CTEs)

CTEs are one of the most powerful SQL features for readability. They let you name and separately define intermediate query steps, making complex queries dramatically easier to understand.

\`\`\`sql
WITH recent_orders AS (
  SELECT
    user_id,
    COUNT(*)      AS order_count,
    SUM(amount)   AS order_total
  FROM orders
  WHERE created_at > NOW() - INTERVAL '30 days'
  GROUP BY user_id
),
premium_users AS (
  SELECT id, name
  FROM users
  WHERE plan = 'premium'
)
SELECT
  pu.name,
  ro.order_count,
  ro.order_total
FROM premium_users pu
JOIN recent_orders ro ON pu.id = ro.user_id;
\`\`\`

The CTE version is self-documenting — you can read it like a series of named steps, even without understanding the full business context.

## Naming Conventions for Tables and Columns

Consistent naming is as important as formatting:

**Table names**: Use plural snake_case nouns (users, orders, product_categories). Table names represent collections of records.

**Column names**: Use snake_case. Avoid reserved words as column names (date, name, value).

**Aliases**: Use meaningful abbreviations. "users u" is acceptable; "users x" is not meaningful.

**Boolean columns**: Prefix with is_ or has_ (is_active, has_premium, is_deleted).

**Timestamp columns**: Use _at suffix (created_at, updated_at, deleted_at).

## Indentation for Subqueries and Nested Logic

Nested subqueries should be indented relative to their parent context to show the hierarchical relationship:

\`\`\`sql
SELECT
  u.name,
  order_counts.total
FROM users u
JOIN (
  SELECT
    user_id,
    COUNT(*) AS total
  FROM orders
  WHERE status = 'completed'
  GROUP BY user_id
) order_counts ON u.id = order_counts.user_id
WHERE u.active = true;
\`\`\`

For deeply nested queries, CTEs are almost always clearer than nested subqueries. If your subquery exceeds 5-6 lines, refactor it as a CTE.

## Comments in SQL

Comments are valuable in complex queries:

\`\`\`sql
-- Single-line: briefly explain a non-obvious condition
WHERE u.deleted_at IS NULL  -- Soft delete: exclude deleted users

/* Multi-line: explain a complex business rule */
\`\`\`

Use comments sparingly for non-obvious logic. If a CTE name or column alias fully explains what it is doing, a comment adds noise rather than clarity. Over-commenting is as bad as under-commenting.

## SQL Formatters and Tooling

Modern editors and database clients include SQL formatters: pgAdmin, DataGrip, Azure Data Studio, and DBeaver all offer formatting. For command-line use, tools like sqlfluff provide linting and formatting that can be integrated into CI pipelines, ensuring consistent SQL style across a codebase.

## Performance-Aware Formatting

When writing complex queries, structure your SQL to match how you think about the query logically — usually starting with the driving table and adding joins and filters. This often produces queries that are both readable and efficient, because the logical flow matches the execution plan the optimizer will likely choose.

Use EXPLAIN or EXPLAIN ANALYZE (in PostgreSQL) or EXPLAIN (in MySQL) to understand how your formatted queries actually execute, and add appropriate indexes to support your most frequent query patterns.

## Conclusion

Readable SQL is a mark of professionalism. Clause-per-line structure, consistent keyword casing, meaningful aliases, and strategic use of CTEs transform complex queries into comprehensible ones. Adopt a style guide for your team and enforce it with tooling — your future self and your colleagues will thank you.`,
  },
  {
    id: 'css-gradient-tutorial',
    title: 'CSS Gradients: A Complete Guide to Linear, Radial, and Conic Gradients',
    description: 'Master CSS gradients — linear, radial, conic, and repeating gradients — with practical examples, browser support notes, and design tips.',
    relatedTool: 'css-gradient',
    category: 'Developer',
    color: 'pink',
    readTime: 8,
    publishDate: '2024-12-10',
    tags: ['css', 'gradients', 'design', 'frontend'],
    relatedBlogs: ['hex-color-guide', 'best-free-text-tools', 'meta-tags-complete-guide'],
    content: `CSS gradients are one of the most powerful visual tools available to frontend developers. They enable smooth transitions between colours without requiring a single image file, are infinitely customisable, scale perfectly at any resolution, and can be combined and layered in creative ways. This guide covers all four types of CSS gradients with practical examples and design guidance.

## What is a CSS Gradient?

A CSS gradient is a function that generates a smooth transition between two or more colours. Because gradients are CSS-generated rather than image-based, they are infinitely scalable (perfect for Retina displays), load instantly (no HTTP request), and can be animated or changed dynamically with JavaScript.

CSS supports four gradient types: linear-gradient() for transitions along a straight line, radial-gradient() for transitions radiating from a point, conic-gradient() for transitions rotating around a point, and repeating variants of each for tiled patterns.

All gradients are used as values for the background or background-image CSS property (not background-color).

## Linear Gradients

The most common gradient type. A linear gradient transitions colours along a straight line from one point to another.

\`\`\`css
/* Using direction keywords */
background: linear-gradient(to right, #3b82f6, #8b5cf6);
background: linear-gradient(to bottom right, #10b981, #3b82f6);

/* Using angles (0deg = bottom to top, 90deg = left to right) */
background: linear-gradient(135deg, #f97316, #ec4899);

/* Multiple colour stops */
background: linear-gradient(to right, #f97316, #ec4899, #8b5cf6);

/* Controlling stop positions */
background: linear-gradient(to right, #3b82f6 0%, #8b5cf6 50%, #ec4899 100%);

/* Hard colour stop (no transition) */
background: linear-gradient(to right, #3b82f6 50%, #8b5cf6 50%);
\`\`\`

**Transparency in gradients**: Avoid using the transparent keyword — it fades through black. Use rgba(r,g,b,0) instead for correct colour preservation:

\`\`\`css
/* Correct fade to transparent */
background: linear-gradient(to bottom, rgba(0,0,0,0.8), rgba(0,0,0,0));
\`\`\`

## Radial Gradients

Radial gradients radiate outward from a central point, creating circular or elliptical patterns. They are ideal for spotlight effects, button highlights, and organic-looking colour transitions.

\`\`\`css
/* Basic circle */
background: radial-gradient(circle, #f97316, #8b5cf6);

/* Positioned centre */
background: radial-gradient(circle at top left, #3b82f6, #1e293b);
background: radial-gradient(circle at 30% 70%, #ec4899, #1e293b);

/* Controlling size */
background: radial-gradient(circle at center, #f97316 0%, transparent 70%);

/* Ellipse (default shape) */
background: radial-gradient(ellipse at center, #10b981, #1e293b);
\`\`\`

Common use cases for radial gradients: spotlight overlays on hero images, soft background glows behind UI cards, vintage vignette effects, and radial menu highlight states.

## Conic Gradients

Conic gradients rotate colours around a central point, like a colour wheel or pie chart. They are newer than linear and radial gradients but have excellent browser support in modern browsers.

\`\`\`css
/* Basic conic gradient (starts at top, goes clockwise) */
background: conic-gradient(red, yellow, green, blue, red);

/* Colour wheel */
background: conic-gradient(
  hsl(0, 100%, 50%),
  hsl(90, 100%, 50%),
  hsl(180, 100%, 50%),
  hsl(270, 100%, 50%),
  hsl(360, 100%, 50%)
);

/* Pie chart effect with hard stops */
background: conic-gradient(#3b82f6 40%, #ec4899 40% 65%, #10b981 65%);

/* Custom starting angle */
background: conic-gradient(from 45deg, red, yellow, green);
\`\`\`

## Repeating Gradients

Repeating gradients tile their pattern across the element, creating geometric patterns and textures.

\`\`\`css
/* Diagonal stripes */
background: repeating-linear-gradient(
  45deg,
  #1e293b 0px,
  #1e293b 10px,
  #334155 10px,
  #334155 20px
);

/* Candy cane effect */
background: repeating-linear-gradient(
  -45deg,
  #ffffff 0%,
  #ffffff 25%,
  #ff0000 25%,
  #ff0000 50%
);
background-size: 40px 40px;

/* Concentric circles */
background: repeating-radial-gradient(
  circle,
  transparent 0,
  transparent 20px,
  rgba(59, 130, 246, 0.3) 20px,
  rgba(59, 130, 246, 0.3) 22px
);
\`\`\`

## Layering Multiple Gradients

CSS backgrounds can be layered — you can combine multiple gradients. Later layers appear below earlier layers.

\`\`\`css
/* Gradient overlay on a gradient background */
background:
  linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)),
  linear-gradient(135deg, #f97316, #8b5cf6);

/* Mesh gradient effect */
background:
  radial-gradient(circle at 20% 30%, rgba(59,130,246,0.15) 0%, transparent 50%),
  radial-gradient(circle at 80% 70%, rgba(236,72,153,0.15) 0%, transparent 50%),
  #0f172a;
\`\`\`

## Practical Design Examples

**Subtle background for cards:**
\`\`\`css
.card {
  background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
  border: 1px solid #d1fae5;
}
\`\`\`

**Gradient text (Webkit required):**
\`\`\`css
.gradient-text {
  background: linear-gradient(135deg, #f97316, #ec4899);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
\`\`\`

**Hero section background:**
\`\`\`css
.hero {
  background:
    linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
    linear-gradient(225deg, rgba(236, 72, 153, 0.1) 0%, transparent 50%),
    #ffffff;
}
\`\`\`

## Animating Gradients

CSS gradients cannot be directly transitioned or animated because they are not a single value type. However, you can animate gradients indirectly using:

- CSS custom properties with @property (Chrome/Edge)
- background-position on large gradient backgrounds to create movement
- opacity transitions between layered gradient elements
- JavaScript to update gradient values via CSS custom properties

The @property approach (now supported in all modern browsers) enables smooth, performant gradient animations entirely in CSS.

## Browser Support

All four gradient types have excellent modern browser support (98%+ globally). The conic-gradient() function required a prefix in older browsers but is now fully supported in all major browsers. There is no need for vendor prefixes in new code targeting modern browsers.

## Performance Tips

Gradients are generally very performant since they are rendered by the GPU. However, very complex gradients with many stops or layered gradients applied to many elements can impact rendering performance on lower-end devices. For animations, prefer animating via CSS custom properties rather than triggering layout recalculations.

## Conclusion

CSS gradients are a design superpower available to every frontend developer. From subtle background washes to complex geometric patterns and UI highlights, gradients add depth, personality, and visual polish without performance cost. Use ToolHub's CSS Gradient Generator to visually create and export gradient code for any design requirement.`,
  },
]
