/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable static export if deploying to Vercel/Netlify without server
  // output: 'export',
}

module.exports = nextConfig
