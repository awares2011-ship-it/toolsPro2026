import type { Metadata } from 'next'
import Script from 'next/script'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import CookieConsent from '@/components/CookieConsent'

// ─── Replace with your real AdSense publisher ID after approval ───────────
const PUBLISHER_ID = 'ca-pub-XXXXXXXXXX'
// ─────────────────────────────────────────────────────────────────────────

export const metadata: Metadata = {
  metadataBase: new URL('https://toolhub.app'),
  title: {
    default:  'ToolHub — Free Developer & Productivity Tools',
    template: '%s — ToolHub',
  },
  description: 'Free, instant, browser-based tools for developers, writers, and SEO professionals. JSON formatter, password generator, word counter, Base64 encoder, and 20+ more. No signup required.',
  keywords: ['free online tools', 'developer tools', 'json formatter', 'password generator', 'word counter', 'seo tools'],
  authors: [{ name: 'Breakout Trade', url: 'https://toolhub.app/about' }],
  creator: 'Breakout Trade',
  publisher: 'Breakout Trade',
  openGraph: {
    siteName: 'ToolHub',
    type: 'website',
    locale: 'en_GB',
  },
  twitter: { card: 'summary_large_image' },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  verification: {
    // ── Add your Google Search Console verification token below ──
    // google: 'YOUR_GSC_VERIFICATION_TOKEN',
  },
}

// Organization schema for Google rich results
const orgSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'ToolHub',
  alternateName: 'Breakout Trade',
  url: 'https://toolhub.app',
  logo: 'https://toolhub.app/icon.png',
  contactPoint: {
    '@type': 'ContactPoint',
    email: 'breakouttradeapp@gmail.com',
    contactType: 'customer support',
    availableLanguage: 'English',
  },
  sameAs: [],
}

const websiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: 'ToolHub',
  url: 'https://toolhub.app',
  description: 'Free browser-based tools for developers, writers, and SEO professionals.',
  potentialAction: {
    '@type': 'SearchAction',
    target: 'https://toolhub.app/?q={search_term_string}',
    'query-input': 'required name=search_term_string',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* ── JSON-LD structured data ───────────────────────────────────── */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
        />

        {/* ── Google AdSense verification ───────────────────────────────────
            Step 1: Uncomment the meta tag below when applying for AdSense.
            Step 2: After approval, uncomment the Script tag in <body>.
            Replace ca-pub-XXXXXXXXXX with your real publisher ID.
        ──────────────────────────────────────────────────────────────────── */}
        {/* <meta name="google-adsense-account" content={PUBLISHER_ID} /> */}
      </head>
      <body className="flex flex-col min-h-screen">

        {/* ── Google AdSense Script ─────────────────────────────────────────
            Uncomment AFTER your AdSense account is approved.
            strategy="afterInteractive" keeps Core Web Vitals scores healthy.
        ──────────────────────────────────────────────────────────────────── */}
        {/* <Script
          async
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${PUBLISHER_ID}`}
          crossOrigin="anonymous"
          strategy="afterInteractive"
        /> */}

        <Header />
        <main className="flex-1">
          {children}
        </main>
        <Footer />
        <CookieConsent />
      </body>
    </html>
  )
}
