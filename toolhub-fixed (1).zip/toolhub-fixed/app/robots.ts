import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      // Allow all well-behaved bots
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/api/',          // no API routes to index
          '/_next/',        // Next.js internals
          '/static/',       // static assets
        ],
      },
      // Block AI training scrapers (optional — remove if you want AI traffic)
      { userAgent: 'GPTBot',      disallow: '/' },
      { userAgent: 'ChatGPT-User',disallow: '/' },
      { userAgent: 'Google-Extended', disallow: '/' },
      { userAgent: 'anthropic-ai',disallow: '/' },
      { userAgent: 'ClaudeBot',   disallow: '/' },
    ],
    sitemap:    'https://toolhub.app/sitemap.xml',
    host:       'https://toolhub.app',
  }
}
