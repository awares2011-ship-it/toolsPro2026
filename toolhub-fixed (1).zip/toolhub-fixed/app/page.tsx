import type { Metadata } from 'next'
import HomepageClient from '@/components/HomepageClient'
import { TOOLS, CATEGORIES } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'

export const metadata: Metadata = {
  title: 'ToolHub — Free Developer & Productivity Tools',
  description: 'Free browser-based tools for developers, writers, and SEO pros. JSON formatter, password generator, word counter, Base64 encoder, and 20+ more. No signup.',
  alternates: { canonical: 'https://toolhub.app' },
}

export default function HomePage() {
  return (
    <HomepageClient
      tools={TOOLS}
      categories={CATEGORIES}
      blogs={BLOGS.slice(0, 6)}
    />
  )
}
